In P2 a&b, H1 and H2 can be directly loaded from 'H1&H2.mat'.
H1 and H2 are given as frequency domain functions.