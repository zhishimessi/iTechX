编译 `pacman.c` 生成可执行文件 `pacman` 或 `pacman.exe` 。

支持命令行参数 `--level n` 和 `--smart-ghost` ，例如 `./pacman --level 3 --smart-ghost` 就是运行第三关，用聪明的鬼。没有 `--level n` 就是从第 0 关开始运行。没有 `--smart-ghost` 就是用来回移动的鬼。

在原有代码的基础上，主要有如下改动：

1. 每一关开始时会求出地图上所有能放角色的位置之间的最短路， `moveOneGhostSmart` 就是按离 Pacman 最短路最短的方向移动鬼， `moveOneGhostNormal` 是来回移动鬼。
2. 重新设计了 `isWall`, `isFood` 等函数的接口。
3. 重新设计了 `printScoreUpdate`, `printFoodUpdate` 的接口，新的接口为 `updateScore` 和 `updateFoodEaten` 。
4. 重新设计了计时方式，不再采用原来的 sleep 的方式，而是不断地用 `clock()` 检测当前时间并和上一次移动鬼的时间作比较，过 0.5s 则移动鬼。
5. 按 ctrl+c 可以退出，退出时能正确地恢复出光标。此前在某些环境下（例如我的 Ubuntu 22.04 fish shell）按 ctrl+c 退出后光标未恢复。
