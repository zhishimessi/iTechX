# Problem 1: Happier Coding

## Problem description

In this task, you need to perform $m$ operations on a sequence of $n$ integers $A=\left\langle a_0,a_1,\cdots,a_n\right\rangle$. Initially, the value of every number in $A$ is zero. Each operation is in the form of three integers $(l,r,x)$, where $0\leqslant l\leqslant r\leqslant n$, for which you need to add $x$ to every number in the index range $[l,r)$, i.e.

$$
\begin{aligned}
  a_l &\gets a_l+x,\\
  a_{l+1} &\gets a_{l+1}+x,\\
  &\cdots,\\
  a_{r-1} &\gets a_{r-1}+x.
\end{aligned}
$$

Nothing is done when $l=r$.

You need to print the sequence after these operations are done.

## Input format

On the first line, two integers $n$ and $m$, separated by a space.

Then follows $m$ lines, each containing three integers $l,r,x$ separated by spaces, indicating an operation.

## Output format

Print $n$ lines, the $i$-th of which ($0\leqslant i<n$) containing an integer, which is the value of $a_i$ after all the operations are done.

## Notes

It is guaranteed that

- $0\leqslant n\leqslant 10^6$, and
- $0\leqslant m\leqslant 10^6$, and
- $\left|a_i\right|\leqslant 10^6$ for every $i\in\{0,1,\cdots,n-1\}$, and
- $|x|\leqslant 10^6$ for every operation.

Note that $n$ and $m$ can be very large. You cannot just loop over all the numbers in the index range $[l,r)$ and add $x$ to each of them for a single operation.

Define a sequence $D=\left\langle d_0,d_1,\cdots,d_{n-1}\right\rangle$, where

$$
d_i=\begin{cases}
a_i,&\text{if }i=0,\\
a_i-a_{i-1},&\text{otherwise},
\end{cases}\quad i=\{0,1,\cdots,n-1\}.
$$

How will this sequence change when one operation $(l,r,x)$ is done? Moreover, if we know the resulting $D$ after all these operations are done, how can we compute $A$ from $D$?

## Example

### Input

```
5 5
2 4 9
1 5 -1
1 5 8
0 1 -7
0 4 2
```

### Output

```
-5
9
18
18
7
```

### Explanation

$\langle 0,0,0,0,0\rangle\xrightarrow{(2,4,9)}\langle 0,0,9,9,0\rangle\xrightarrow{(1,5,-1)}\langle 0,-1,8,8,-1\rangle\xrightarrow{(1,5,8)}\langle 0,7,16,16,7\rangle\xrightarrow{(0,1,-7)}\langle -7,7,16,16,7\rangle\xrightarrow{(0,4,2)}\langle -5,9,18,18,7\rangle$.