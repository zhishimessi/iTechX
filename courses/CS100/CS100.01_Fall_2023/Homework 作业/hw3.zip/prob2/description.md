# Problem 2: Very Simple String Problem

## Problem description

You are given a string $s=s_0s_1\cdots s_{L-1}$ of length $L$ consisting of only lower- and upper-case English letters. You need to answer $n$ queries.

A query is in the form of a pair of integers $(a,b)$, where $0\leqslant a,b\leqslant L$. Let $p=s_as_{a+1}\cdots s_{L-1}$ and $q=s_bs_{b+1}\cdots s_{L-1}$ be two substrings of $s$. You need to compare the two substrings $p$ and $q$ lexicographically. If $p<_{\text{lex}}q$, print $s_as_{a+1}\cdots s_{L-1}s_bs_{b+1}\cdots s_{L-1}$; otherwise print $s_bs_{b+1}\cdots s_{L-1}s_as_{a+1}\cdots s_{L-1}$.

Note that $a$ and $b$ may be equal to $L$, in which case the substring is an empty string. An empty string is lexicographically less than any non-empty string.

## Input format

On the first line, a string $s^\prime$. Note that this string **is not $s$**. It may contain characters that are not English letters, which you need to filter out.

On the second line, a non-negative integer $n$.

Then come $n$ lines, each containing two integers $a$ and $b$ separated by a space, representing a query.

## Output format

$n$ lines, each containing the answer to the corresponding query.

## Example

### Input

```
ab?"B bCbB;
3
7 2
5 1
5 4
```

### Output

```
BbCbB
bBbBbCbB
CbBbB
```

### Explanation

$s$ is `abBbCbB`.

For the first query $(7,2)$, $p$ is the empty string and $q$ is `BbCbB`.

For the second query $(5,1)$, $p$ is `bB` and $q$ is `bBbCbB`.

For the third query $(5,4)$, $p$ is `bB` and $q$ is `CbB`. Note that `C` is less than `b` lexicographically, because `C` is an uppercase letter (whose ASCII values are smaller than those of the lowercase letters).

## Notes

Let $L^\prime$ be the length of the input string $s^\prime$. It is guaranteed that $L^\prime\leqslant 10^6$, and that $L^\prime n\leqslant 2\times 10^7$.

## Special requirements

This problem is indeed simple, but some beginners may still write very complicated code, which is not a good habit.

In this problem, your code must meet the following requirements, or you will receive 0 points.

- For each query, the comparison of two substrings must be done by **exactly one call to `strcmp` or `strncmp`**.
- For each query, you should not use a loop to print the answer. The answer to one query should be printed using only one or two calls to some standard library function (such as `printf`).
- You are only allowed to create **one array**, whose element type is `char` and length is approximately $10^6$ (maybe a little bit larger).

Note that these things will not be checked on OJ, but we will check manually.