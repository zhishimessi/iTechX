# Problem 2: Sum of numbers

## Description

Class Exercise 1

Write a program that reads an unknown number of integers from input until 0 is entered. Print the sum of these integers.

## Input format

Each line contains an integer $s_i$, terminated with 0.

- For 100% cases, $|s_i|\leq 100$.

## Output format

An integer representing the sum of these integers

## Example

Input:
```
1
2
3
0
```

Output:
```
6
```
