# Problem 1: Find Bugs!

## Description

Your friend has just started learning programming, and has spent hours on a textbook practice problem. He/She asks you for help by treating you to a KFC Crazy Thursday meal. You agree, and he/she sends you a `.txt` file:

```
#include <sudo.h>

void main（）
{
	// Calculate the average score of all students in a class.

	int num;
	int sum;

	printf('How many students are there?/n')
	scanf('d%', num)
	printf("What are their scores?/n")

	// We programmers count from zero!
	for (int i = 0, i <= num, i++);
	{
		int sum, score;
		scanf("d%", score);
		sum += score;
	}

	double average = sum / num;
	if (average = 60)
		printf('Good!/n');
	if (average > 60)
		printf('Excellent!/n');
	else
		printf(“Bad!/n”);

	printf("Average score is &.2f./n", average);

	return 0;
}
```

For the sake of Crazy Thursday, you now have the responsibility to debug your friend's code (Don't do so in ShanghaiTech!). You may first fix compile errors so that the code runs, and then figure out why it (possibly) does not produce correct results.

## Input format

The first line contains a number $n$, representing the number of students in a class.

The following $n$ lines each contain $s_i$, score of a student.

- For 100% cases, $0<n\leq 50$ and $0\leq s_i\leq 100$.

## Output format

Four sentences, specified as in `printf` statements in the code. 

In the last sentence, round the average score to **two decimal places**.

## Example

Input:
```
2
70 
81
```

Output:
```
How many students are there?
What are their scores?
Excellent!
Average score is 75.50.
```
