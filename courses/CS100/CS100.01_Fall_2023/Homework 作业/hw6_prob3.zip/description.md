# Expression

## Background

In this problem, we deal with trees that represent arithmetic expressions. We first consider only the expressions consisting of numbers (constants), the unary `+` and `-` operators, and the binary `+`, `-`, `*` and `/` operators. Such expressions can be represented by a tree structure, which is named **expression trees** or **abstract syntax trees (AST)**. For example, the tree representing `2 + (4 - 5 / (-6)) * 3` is

![](img/exprtree.png)

Such a tree is quite useful, as it contains the structure of all subexpressions. We may perform some operations on the tree recursively, such as printing, evaluation, conversion to some special forms, etc. Now your task is to build a class hierarchy representing these different kinds of nodes. Parsing an expression into an AST is beyond the scope of CS100.

## The basic structure

We start from the following basic structure.

```cpp
class ExprNode {
public:
  ExprNode() = default;
  virtual double eval() const = 0;
  virtual std::string rep() const = 0;
  virtual ~ExprNode() = default;
};

class Constant : public ExprNode {
  double mValue;

public:
  explicit Constant(double value) : mValue{value} {}
  // eval and rep ...
};

enum class UnaryOpKind {
  UOK_Plus, UOK_Minus
};

class UnaryOperator : public ExprNode {
  UnaryOpKind mOpKind;
  std::shared_ptr<ExprNode> mOperand;

public:
  UnaryOperator(UnaryOpKind op, std::shared_ptr<ExprNode> operand)
      : mOpKind{op}, mOperand{std::move(operand)} {}
  // eval and rep ...
};

enum class BinaryOpKind {
  BOK_Plus, BOK_Minus, BOK_Mul, BOK_Div
};

class BinaryOperator : public ExprNode {
  BinaryOpKind mOpKind;
  std::shared_ptr<ExprNode> mLeft;
  std::shared_ptr<ExprNode> mRight;

public:
  BinaryOperator(BinaryOpKind op, std::shared_ptr<ExprNode> left, std::shared_ptr<ExprNode> right)
      : mOpKind{op}, mLeft{std::move(left)}, mRight{std::move(right)} {}
  // eval and rep ...
};
```

It seems to be a nice hierarchy, but how does the user create a node? The user has to write

```cpp
// The BinaryOperator is created statically.
BinaryOperator bo1(BinaryOpKind::BOK_Plus, std::make_shared<Constant>(3), std::make_shared<Constant>(4));
//The BinaryOperator is created dynamically.
auto bo2 = std::make_shared<BinaryOperator>(BinaryOpKind::BOK_Plus, std::make_shared<Constant>(3), std::make_shared<Constant>(4));
```

which involves creating the `shared_ptr`s manually. This is too ugly and inconvenient.

## A level of indirection

Here goes the so-called "Fundamental Theorem of Software Engineering":

> We can solve any problem by introducing an extra level of indirection.

Our problem is that the user still has to do memory management (even though smart pointers are used), which should be our implementation details. The user should only care about the structure of the tree. For example, we expect the user to be able to create a node in the following way

```cpp
Expr bo('+', Expr(3), Expr(4));
```

or even more conveniently like

```cpp
auto bo = Expr(3) + Expr(4);
```

Let's consider defining the `Expr` class, which works as the level of indirection between the user and the specific node classes. The class `Expr` should encapsulate a `std::shared_ptr<ExprNode>` and hide everything related to memory management from the user. Moreover, `Expr` should also provide the interfaces like `eval()` and `rep()`.

```cpp
class Expr {
  std::shared_ptr<ExprNode> mNode;

  Expr(std::shared_ptr<ExprNode> ptr) : mNode{std::move(ptr)} {}

public:
  // To enable the usage like `Expr(3)`.
  Expr(double value) : mNode{std::make_shared<Constant>(value)} {}
  auto rep() const { return mNode->rep(); }
  auto eval() const { return mNode->eval(); }

  // friend declarations, if necessary ...
};
```

Since `Expr` is a wrapper of a `std::shared_ptr<ExprNode>`, it should have a constructor that initializes that `shared_ptr` member. We make this constructor `private` because we don't want the user to call it directly.

Now let's think about what `Expr` actually does. It contains a smart pointer to some node class, and behaves very much like a node class, since it has the interfaces `rep()` and `eval()`. Such a class that represents an object of any node type perfectly and does memory management internally is called a *handle*.

With this handle class defined, wherever a `std::shared_ptr<ExprNode>` is needed, a `Expr` can always work. The other node classes can simply replace every `std::shared_ptr<ExprNode>` with `Expr` and completely forget about how the memory is managed:

```cpp
class UnaryOperator : public ExprNode {
  UnaryOpKind mOpKind;
  Expr mOperand;

public:
  UnaryOperator(UnaryOpKind op, Expr operand)
      : mOpKind{op}, mOperand{std::move(operand)} {}
  
  // eval and rep ...
};
```

The user may create a `UnaryOperator` node through the following overloaded operators:

```cpp
Expr operator-(const Expr &arg) {
  return {std::make_shared<UnaryOperator>(UnaryOpKind::UOK_Minus, arg)};
}
Expr operator+(const Expr &arg) {
  return {std::make_shared<UnaryOperator>(UnaryOpKind::UOK_Plus, arg)};
}
```

For example,

```cpp
auto neg3 = -Expr(3);
```

## More functionalities

With basic knowledge on our class hierarchy obtained, you are going to add support for more functionalities:

- A new kind of node called `Variable`, which represents the varaible `x`. With this supported, our AST can be used to represent unary functions, instead of only arithmetic expressions with constants.
- Evaluation of the function at a certain point $x=x_0$.
- Evaluation of the derivative of the function at a certain point $x=x_0$.

The operations that need to be supported are declared in this base class:

```cpp
class NodeBase {
public:
  // Make any of these functions virtual, or pure virtual, if necessary.
  NodeBase() = default;
  double eval(double x) const;       // Evaluate f(x)
  double derivative(double x) const; // Evaluate df(x)/dx
  std::string rep() const;           // Returns the parenthesized representation of the function.
  ~NodeBase() = default;
};
```

In the previous sections, we used only one class `BinaryOperator` to represent four different kinds of binary operators. Such design may not be convenient for this problem, because the ways of evaluating the function and its derivative differ to a greater extent between different operators. Therefore, we separate them into four classes:

```cpp
class BinaryOperator : public NodeBase {
protected:
  Expr mLeft;
  Expr mRight;

public:
  BinaryOperator(Expr left, Expr right)
      : mLeft{std::move(left)}, mRight{std::move(right)} {}
};

class PlusOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;
  // eval and rep ...
};

class MinusOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;
  // eval and rep ...
};

class MultiplyOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;
  // eval and rep ...
};

class DivideOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;
  // eval and rep ...
};
```

By declaring `using BinaryOperator::BinaryOperator;`, we are **inheriting** the constructor from `BinaryOperator`. For example, the class `PlusOp` now has a constructor like this:

```cpp
class PlusOp : public BinaryOperator {
public:
  PlusOp(Expr left, Expr right) : BinaryOperator(std::move(left), std::move(right)) {}
};
```

and the same for `MinusOp`, `MultiplyOp` and `DivideOp`.

To support the variable `x`, we define a new class `Variable`:

```cpp
class Variable : public NodeBase {
  // eval and rep ...
};
```

Then we define a `static` data member of `Expr` as follows.

```cpp
class Expr {
  std::shared_ptr<NodeBase> mNode;

  Expr(std::shared_ptr<NodeBase> ptr) : mNode{std::move(ptr)} {}

public:
  Expr(double value);

  static const Expr x;
  // Other members ...
};

// After the definition of `Variable`:
const Expr Expr::x{std::make_shared<Variable>()};
```

Note that `Expr` also has a non-`explicit` constructor that receives a `double` and creates a `Constant` node:

```cpp
Expr::Expr(double value) : mNode{std::make_shared<Constant>(value)} {}
```

With all of these, and the overloaded arithmetic operators defined, we can create functions in a very convenient manner:

```cpp
auto &x = Expr::x;
auto f = x * x + 2 * x + 1; // x^2 + 2x + 1
std::cout << f.rep() << std::endl; // (((x) * (x)) + ((2.000000) * (x))) + (1.000000)
std::cout << f.eval(3) << std::endl; // 16
std::cout << f.derivative(3) << std::endl; // 8
auto g = f / (-x * x + x - 1); // (x^2 + 2x + 1)/(-x^2 + x - 1)
std::cout << g.eval(3) << std::endl; // -2.28571
std::cout << g.derivative(3) << std::endl; // 0.489796
```

## Requirements for `rep()`

Note: This is a very simple and naive way to convert an expression to a string, because we don't want to set barriers on this part. You can search for some algorithms to make the expression as simplified as possible, but it may not pass the OJ tests.

Any operand of the unary operators (`+`, `-`) or the binary operators (`+`, `-`, `*`, `/`) should be surrounded by a pair of parentheses. Correct examples:
- $2+3$: `(2.000000) + (3.000000)`
- $2x+3$: `((2.000000) * (x)) + (3.000000)`
- $2\cdot(-x)+3$: `((2.000000) * (-(x))) + (3.000000)`

There should be a space before and after each binary operator. For example, `(expr1) + (expr2)` instead of `(expr1)+(expr2)`.

To convert a floating-point number to `std::string`, just use `std::to_string` and you will be free of troubles caused by precisions and floating-point errors.

Note: If the floating-point value of a `Constant` node is negative, it is **not** treated as a unary minus sign applied to its absolute value. For example,

```cpp
Expr e(-2);
std::cout << e.rep() << std::endl;
```

The output should be `-2.000000` instead of `-(2.000000)`.

`example.cpp` contains these simple tests.

## Requirements for `Expr`

From the user's perspective, only `Expr` and its arithmetic operators are **interfaces**. Anything else in your code is **implementation details**, which user code will not rely on. In other words, you are free to implement these things in any way, as long as the interfaces of `Expr` meet our requirements.

- `Expr` is copy-constructible, copy-assignable, move-constructible, move-assignable and destructible. These operations should just perform the corresponding operations on the member `mNode`, and let the corresponding function of `std::shared_ptr` handle everything. The move operations should be `noexcept`.
- `Expr` is constructible from a `double` value, and this constructor is non-`explicit`.
- Let `e` be `const Expr` and `x0` be `double`, then the subtree rooted at `e` represents a function. `e.eval(x0)` returns the value of this function at $x=x_0$. `e.derivative(x0)` returns the value of the derivative of this function at $x=x_0$. `e.rep()` returns a `std::string` representing this function.
- Let `e1` and `e2` be two objects of type `const Expr`. The following expressions return an object of type `Expr`, which creates a new node corresponding to the operators.
  - `-e1`
  - `+e1`
  - `e1 + e2`
  - `e1 - e2`
  - `e1 * e2`
  - `e1 / e2`
- `Expr::x` is an object of type `const Expr`, which represents the variable `x`.

Use `compile_test.cpp` to check whether your code compiles.

## Submission

Submit `expr.hpp` or its contents to OJ.

## Thinking

Why do we use `std::shared_ptr` instead of `std::unique_ptr`?

Can you add support for more functionalities, e.g. the elementary functions $\sin(e)$, $\cos(e)$, exponential expressions $e_1^{e_2}$, ...? More variables? Print expressions to $\LaTeX$?
