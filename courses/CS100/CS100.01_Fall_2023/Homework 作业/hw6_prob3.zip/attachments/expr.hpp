#ifndef EXPR_HPP
#define EXPR_HPP

#include <memory>
#include <string>

class ExprNode {
public:
  // FIXME: Make any of these functions virtual, or pure virtual, if necessary.
  ExprNode() = default;
  double eval(double x) const;
  double derivative(double x) const;
  std::string rep() const;
  ~ExprNode() = default;
};

class Expr {
  std::shared_ptr<ExprNode> mNode;

  Expr(std::shared_ptr<ExprNode> ptr) : mNode{std::move(ptr)} {}

public:
  Expr(double value);

  // TODO: Add member functions if necessary.

  static const Expr x;

  // TODO: Add friend declarations if necessary.
};

class Variable : public ExprNode {
  // TODO: eval and rep ...
};

const Expr Expr::x{std::make_shared<Variable>()};

class Constant : public ExprNode {
  double mValue;

  // TODO: eval and rep ...

public:
  explicit Constant(double value) : mValue{value} {}
};

Expr::Expr(double value) : mNode{std::make_shared<Constant>(value)} {}

enum class UnaryOpKind {
  UOK_Plus, UOK_Minus
};

class UnaryOperator : public ExprNode {
  UnaryOpKind mOpKind;
  Expr mOperand;

  // TODO: eval and rep ...

public:
  UnaryOperator(UnaryOpKind op, Expr operand) : mOpKind{op}, mOperand{std::move(operand)} {}
};

class BinaryOperator : public ExprNode {
protected:
  Expr mLeft;
  Expr mRight;

public:
  BinaryOperator(Expr left, Expr right)
      : mLeft{std::move(left)}, mRight{std::move(right)} {}
};

class PlusOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;

  // TODO: eval and rep ...
};

class MinusOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;

  // TODO: eval and rep ...
};

class MultiplyOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;

  // TODO: eval and rep ...
};

class DivideOp : public BinaryOperator {
  using BinaryOperator::BinaryOperator;

  // TODO: eval and rep ...
};

// TODO: Add functions if necessary.

#endif // EXPR_HPP