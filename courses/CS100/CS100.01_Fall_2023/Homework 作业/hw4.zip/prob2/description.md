# Problem 2. Design Thinking

## Problem description

Design **at least two** classes on your own, using what you have learned.

You can choose any topic that you can come up with, e.g. mathematical concepts, data structures, game characters, digital signals, embedded systems, bookshop management, course scheduler, employee registration, etc. Use C++ classes to model it.

Your classes should meet the following requirements:

1. Design and modeling:
   - The classes should be meaningful and model some real-world thing. You cannot write meaningless toys like `struct X { int value; };`. The functions should do something meaningful, not just printing `"Hello, world"`.
   - The design should make sense. What need to be stored as data members? What interfaces should be provided for users? What should be the behaviors of initialization and destruction?
   - It should not be class examples or from other problems in this homework.
2. Practice what you have learned: (The OJ will test this.)
   - All classes and members should be named in a meaningful and consistent manner.
   - All the data members should be `private`.
   - All classes should have user-provided constructors.
     - At least one class should have a user-provided (or `=default`) default constructor.
     - At least one class should have no (or `=delete`) default constructor.
     - At least one class should have more than one user-provided constructors that are not default/copy/move constructors.
     - Use constructor initializer lists whenever possible.
     - Avoid uninitialized scalars whenever possible.
   - At least one class should have a user-provided destructor, with its function body not empty.
   - All classes should have user-provided member functions (apart from constructors and destructors).
     - At least one class should have a `const` member function.
     - At least one class should have a non-`const` member function.

## Grading

The grading of this problem consists of two parts: The OJ, and an offline check with TA.

Write your classes in one file and submit it to the OJ. The OJ will test whether your submission meets the requirements 2.

You will get 100 points in this problem proided that
- the OJ tests are passed, and that
- your classes are meaningful and model some real-world thing, and that
- you've participated in the offline check with TA.

As beginners, you are not required to achieve perfection in designs, so the score will not be affected as long as you've written something meaningful.