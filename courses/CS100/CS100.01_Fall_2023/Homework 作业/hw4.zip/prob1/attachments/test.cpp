#include "joiner.hpp"

#include <iostream>
#include <string>
#include <vector>

void print_strings_twice() {
  Joiner comma(", ");
  const auto strings = {"hello", "world", "modern", "c++"};
  for (const auto &s : strings)
    std::cout << comma.get() << s;
  std::cout << '\n';

  comma.reset();
  for (const auto &s : strings)
    std::cout << comma.get() << s;
  std::cout << std::endl;
}

std::string concatenate_ints(const std::string &sep) {
  const auto ints = {3, 1, 4, 1, 5, 9};
  std::string result;
  Joiner joiner(sep);
  for (auto x : ints)
    result += joiner.get() + std::to_string(x);
  return result;
}

void print_2d_table(const std::vector<std::vector<int>> &table) {
  Joiner newline('\n');
  for (const auto &row : table) {
    std::cout << newline.get();
    Joiner comma(", ");
    for (auto x : row)
      std::cout << comma.get() << x;
  }
  std::cout << std::flush;
}

void special() {
  std::string s1 = "helloworld", s2 = "CS100Homework4";
  Joiner j(s1 + s2);
  std::cout << j.get(); // Nothing
  std::cout << j.get() << '\n'; // `helloworldCS100Homework4`.
}

int main() {
  print_strings_twice(); // It should print `hello, world, modern, c++` twice.

  // The following should print `3xx1xx4xx1xx5xx9`.
  std::cout << concatenate_ints("xx") << std::endl;

  std::vector table(3, std::vector(4, 0));
  print_2d_table(table); // The output should be:
                         // 0, 0, 0, 0
                         // 0, 0, 0, 0
                         // 0, 0, 0, 0
  std::cout << '\n';
  
  special();
  return 0;
}