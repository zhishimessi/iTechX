#ifndef JOINER_HPP
#define JOINER_HPP

#include <string>

class Joiner {};

#endif // JOINER_HPP