# Problem 1. Joiner

## Problem description

Sometimes we want to produce a long string by concatenating a sequence of strings one by one, with a joiner inserted in between each string. For example:

```cpp
std::string join(const std::string &joiner, const std::vector<std::string> &strings) {
  if (strings.empty())
    return {};
  auto result = strings.front();
  for (std::size_t i = 1; i != strings.size(); ++i)
    result += joiner + strings[i];
  return result;
}
void print(const std::vector<int> &ints, const std::string &sep = " ") {
  for (std::size_t i = 0; i != ints.size(); ++i) {
    std::cout << ints[i];
    if (i + 1 != ints.size())
      std::cout << sep;
  }
  std::cout << std::flush;
}
```

To be honest, it is not comfortable to write such code. The problem lies in two things:
- The `if` statements - We always have to deal with special cases, which is annoying.
- The subscript-based `for` loops - We intended to **traverse the given `vector`**, which should be done by a range-based `for` loop. However, in both implementations we have to use subscripts.

In this task, we will see how C++ classes assist us in such problems. We can design a `Joiner` class representing a "joiner", which is a string that hides itself when it is accessed for the first time. For example, with this class, we should be able to write the `print` function straightforwardly using a range-`for`:

```cpp
void print(const std::vector<int> &ints, const std::string &sep = " ") {
  Joiner joiner(sep);
  for (auto x : ints)
    std::cout << joiner.get() << x;
  std::cout << std::flush;
}
int main() {
  std::vector v{1, 2, 3};
  print(v); // It should print `1 2 3`.
  print(v, ", "); // It should print `1, 2, 3`.
}
```

## Detailed requirements

Go to Piazza to download the files related to this problem.

There is a folder named `attachments` containing two files: `joiner.hpp` and `test.cpp`. `joiner.hpp` is where you should define your class `Joiner`. This file is `#include`d by `test.cpp`.

All you need to do is to make the code in `test.cpp` compile and produce the desired outputs. We will not provide any more explanations here.

Remember to avoid unnecessary copies of strings.

## Submission

Submit the contents of `joiner.hpp` to the OJ.