#ifndef SUDOKUBOARD_HPP
#define SUDOKUBOARD_HPP

#include <iostream>
#include <utility>

class SudokuBoard {
  friend std::ostream &operator<<(std::ostream &, const SudokuBoard &);

  int mBoard[9][9];
  bool mRowUsed[9][10]{};
  bool mColUsed[9][10]{};
  bool mBoxUsed[3][3][10]{};

public:
  SudokuBoard(std::istream &is) {
    for (auto i = 0; i != 9; ++i)
      for (auto j = 0; j != 9; ++j) {
        is >> mBoard[i][j];
        if (mBoard[i][j] != 0) {
          mRowUsed[i][mBoard[i][j]] = true;
          mColUsed[j][mBoard[i][j]] = true;
          mBoxUsed[i / 3][j / 3][mBoard[i][j]] = true;
        }
      }
  }

  bool fitsIn(int row, int col, int x) const {
    return !mRowUsed[row][x] && !mColUsed[col][x] &&
           !mBoxUsed[row / 3][col / 3][x];
  }

  void reset(int row, int col) {
    int x = mBoard[row][col];
    mRowUsed[row][x] = false;
    mColUsed[col][x] = false;
    mBoxUsed[row / 3][col / 3][x] = false;
    mBoard[row][col] = 0;
  }

  class AttemptGuard {
    SudokuBoard *mBoardIfSuccess{nullptr};
    int mRow, mCol;

  public:
    AttemptGuard(SudokuBoard *board, int r, int c)
        : mBoardIfSuccess{board}, mRow{r}, mCol{c} {}
    AttemptGuard() = default;
    ~AttemptGuard() {
      if (mBoardIfSuccess)
        mBoardIfSuccess->reset(mRow, mCol);
    }
    explicit operator bool() const { return mBoardIfSuccess; }
  };

  AttemptGuard tryFill(int row, int col, int x) {
    if (fitsIn(row, col, x)) {
      mBoard[row][col] = x;
      mRowUsed[row][x] = true;
      mColUsed[col][x] = true;
      mBoxUsed[row / 3][col / 3][x] = true;
      return {this, row, col};
    } else
      return {};
  }

  bool isEmpty(int row, int col) const { return mBoard[row][col] == 0; }
};

std::ostream &operator<<(std::ostream &os, const SudokuBoard &board) {
  for (const auto &row : board.mBoard) {
    for (auto x : row)
      os << x << ' ';
    os << '\n';
  }
  return os << std::flush;
}

#endif // SUDOKUBOARD_HPP