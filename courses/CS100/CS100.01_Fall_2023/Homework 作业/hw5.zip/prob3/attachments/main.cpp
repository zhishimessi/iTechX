#include "SudokuBoard.hpp"

void search(SudokuBoard &board, int row, int col) {
  // TODO: Starting from (row, col), find the first empty cell.

  if (/* TODO: There is no empty cell.*/) {
    // TODO: Print the board.
    return;
  }
  for (auto x = 1; x <= 9; ++x) {
    // TODO: Try filling the cell (row, col) with x.
    // Make use of board.tryFill, as well as the destructor of its return type.
    // Then, search recursively.
  }
}

int main() {
  SudokuBoard board(std::cin);
  search(board, 0, 0);
  return 0;
}