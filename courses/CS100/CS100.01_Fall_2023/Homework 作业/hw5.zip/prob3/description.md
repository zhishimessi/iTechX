# Problem 3. Sudoku

Go to Piazza Resources to download the attachments for this problem.

## Problem description

First, get familiar with the [Sudoku](https://en.wikipedia.org/wiki/Sudoku) puzzles. From Wikipedia:

> Sudoku is a logic-based, combinatorial number-placement puzzle. The objective is to fill a $9\times 9$ grid with digits so that each column, each row and each of the nine $3\times 3$ subgrids (also called "boxes", "blocks" or "regions") that compose the grid contains all of the digits $\{1,2,\cdots,9\}$.

Not only is Sudoku a good exercise for human brains, but it is also a typical programming task that involves **backtracking search**. The idea is simple: We just enumerate all possible digits for each empty cell, and try filling them into the empty cells.

![](img/sudoku_tree.png)

In this problem, you are required to write a program that reads in a Sudoku board and prints **all solutions** to it.

## Algorithm

We will start from the top-left corner, and try filling the empty cells one-by-one, from the top row to the bottom row, and on each row we fill in the empty cells from left to right, until we hit the bottom-right corner. We say a cell $(r_2,c_2)$ is ***after*** the cell $(r_1,c_1)$ if either

- $r_1<r_2$, or
- $r_1=r_2$ and $c_1<c_2$.

The algorithm is recursive:

![](img/sudoku_algo.png)

Note that this `search` function will first examine whether the cell $(r,c)$ is empty, and if not, it will move to the first empty cell ***after*** $(r,c)$. To trigger the search process, we only need to call `search(0, 0)`.

## Implementation

Implement the algorithm in the file `main.cpp`. We have already provided you with a framework.

We have implemented many of the functionalities for you. First, you need to read through the code in `SudokuBoard.hpp` and understand what each function is doing. Remember that **reading and learning from good code is also an important part in programming study**.

The class `SudokuBoard` stores four arrays: `mBoard[i][j]` is the current digit in the cell $(i,j)$, and zero if it is empty. The other three are for checking the usage of digits on each row/column/box. For example, `mRowUsed[r][x]` is true if and only if $x$ has been used on the $r$-th row.

These arrays help us check whether a digit $x$ fits in a cell $(r,c)$ quite efficiently, but we must remember to update their values when filling or erasing a digit. More specifically:

- When we fill the cell $(r,c)$ with $x$, we need to set `mBoard[r][c] = x` and also update the other arrays:
  ```cpp
  mRowUsed[r][x] = true;
  mColUsed[c][x] = true;
  mBoxUsed[r / 3][c / 3][x] = true;
  ```
- When doing backtracking, we also need to reset `mRowUsed[r][x]`, `mColUsed[c][x]` and `mBoxUsed[r / 3][c / 3][x]`.

The magic happens in the function `SudokuBoard::tryFill` and its return type `AttemptGuard`. Understand how they are designed, and try to make full use of them.

Implement the algorithm in `main.cpp` with the help of the code in `SudokuBoard.hpp`.

## Test

### Input format

9 lines, each consisting of 9 digits separated with space, indicating the initial Sudoku board.

Zero is used to represent an empty cell.

### Output format

Print all solutions to the input puzzle. Two solutions should be separated by an empty line.

Trailing spaces and lines are allowed.

### Example input

```
0 0 4 3 5 0 8 0 7 
0 0 3 7 6 8 0 0 9 
7 0 0 0 0 0 2 6 0 
3 0 2 6 0 5 9 8 1 
0 0 0 0 3 0 0 0 0 
0 9 0 2 8 0 0 7 6 
0 3 0 0 0 7 1 2 0 
0 0 0 0 0 6 7 0 5 
1 0 0 5 4 3 6 0 0 
```

### Example output

```
9 6 4 3 5 2 8 1 7 
2 1 3 7 6 8 4 5 9 
7 5 8 4 1 9 2 6 3 
3 4 2 6 7 5 9 8 1 
8 7 6 9 3 1 5 4 2 
5 9 1 2 8 4 3 7 6 
6 3 5 8 9 7 1 2 4 
4 8 9 1 2 6 7 3 5 
1 2 7 5 4 3 6 9 8 

9 6 4 3 5 2 8 1 7 
2 1 3 7 6 8 5 4 9 
7 5 8 4 1 9 2 6 3 
3 4 2 6 7 5 9 8 1 
8 7 6 9 3 1 4 5 2 
5 9 1 2 8 4 3 7 6 
6 3 5 8 9 7 1 2 4 
4 8 9 1 2 6 7 3 5 
1 2 7 5 4 3 6 9 8 
```

We have provided you with 10 testcases as well as their solutions, in `attachments/data`.

## Submission

Submit the contents of `main.cpp` to the OJ.
