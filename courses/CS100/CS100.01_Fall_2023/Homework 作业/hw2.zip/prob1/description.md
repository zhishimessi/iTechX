# Problem 1: Happy Coding

## Problem description

You are given a sequence of non-zero integers $a_0,a_1,\cdots,a_{n-1}$ and $q$ queries. Each query is in the form of a pair of integers $(l,r)$, where $0\leqslant l\leqslant r\leqslant n$, for which you need to calculate and print the value of

$$
\sum_{i=l}^{r-1}a_i.
$$

The above sum equals to zero when $l=r$.

## Input format

First, you need to read $n$ integers $a_0,a_1,\cdots,a_{n-1}$, where $n$ is not known. The end of this sequence is marked by zero, and you need to determine the value of $n$ from this. Each integer (including the ending zero) appears on a single line.

On the $(n+2)$-th line is a non-negative integer $q$, indicating the number of queries.

Then $q$ lines follow, each containing two integers $l$ and $r$, representing a query.

## Output format

$q$ lines, the $i$-th of which contains an integer representing the answer to the $i$-th query.

## Notes

It is guaranteed that:

- $0\leqslant n\leqslant 10^6$, and
- $0\leqslant q\leqslant 10^6$, and
- $\left|a_i\right|\leqslant 10^6$ and $a_i\neq 0$ for every $i\in[0,n)$.

Note that $n$ and $q$ can be very large. You cannot just loop over all the numbers in the index range $[l,r)$ and sum them up to answer a single query.

Define

$$
s_i=\sum_{j=0}^{i-1}a_j,\quad i\in\{1,\cdots,n\}.
$$

Think about how this sequence can help.

## Example

### Input

```
1
-4
2
8
-5
6
11
0
3
1 5
3 7
2 2
```

### Output

```
1
20
0
```

### Explanation

The sequence is $\{a_i\}_{i=0}^{n-1}=\langle 1,-4,2,8,-5,6,11\rangle$ and $n=7$.

The number of queries is $q=3$.

The first query is $(1,5)$, the answer to which is $-4+2+8+(-5)=1$.

The second query is $(3,7)$, the answer to which is $8+(-5)+6+11=20$.

The third query is $(2,2)$, the answer to which is $0$.