#include <stdio.h>

int main(void) {
  int sum = 0;

  while (1) {
    int number;
    scanf("%d", &number);
    if (number == 0)
      break;
    sum += number;
  }

  printf("%d\n", sum);

  return 0;
}