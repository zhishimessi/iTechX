#include <stdio.h>
#include <math.h>

int main(void) {
  int num;
  printf("How many students are there?\n");
  scanf("%d", &num);
  printf("What are their scores?\n");

  int sum = 0;
  for (int i = 0; i < num; ++i) {
    int score;
    scanf("%d", &score);
    sum += score;
  }

  double average = 1.0 * sum / num;

  if (fabs(average - 60) < 1e-8)
    printf("Good!\n");
  else if (average > 60)
    printf("Excellent!\n");
  else
    printf("Bad!\n");

  printf("Average score is %.2lf.\n", average);
  return 0;
}