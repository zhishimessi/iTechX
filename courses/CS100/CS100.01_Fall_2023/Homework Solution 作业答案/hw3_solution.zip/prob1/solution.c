#include <stdio.h>

int main(void) {
  int n, m;
  scanf("%d%d", &n, &m);
  static long long d[1000001];
  while (m--) {
    int l, r, x;
    scanf("%d%d%d", &l, &r, &x);
    d[l] += x;
    d[r] -= x;
  }
  printf("%lld\n", d[0]);
  for (int i = 1; i < n; ++i) {
    d[i] += d[i - 1];
    printf("%lld\n", d[i]);
  }
  return 0;
}