#include <stdio.h>
#include <string.h>
#include <ctype.h>

char str[1000001];

int main(void) {
  char c = getchar();
  int length = 0;
  while (c != '\n') {
    if (isalpha(c))
      str[length++] = c;
    c = getchar();
  }
  int n;
  scanf("%d", &n);
  while (n--) {
    int a, b;
    scanf("%d%d", &a, &b);
    int result = strcmp(str + a, str + b);
    if (result < 0)
      printf("%s%s\n", str + a, str + b);
    else
      printf("%s%s\n", str + b, str + a);
  }
  return 0;
}