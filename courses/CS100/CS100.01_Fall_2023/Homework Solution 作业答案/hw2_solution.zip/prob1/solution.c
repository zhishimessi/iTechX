#include <stdio.h>

#define MAXN 1000000

int main(void) {
  int n = 0;
  static int a[MAXN];
  static long long s[MAXN + 1];
  int x;
  while (1) {
    scanf("%d", &x);
    if (x != 0)
      a[n++] = x;
    else
      break;
  }
  for (int i = 0; i != n; ++i)
    s[i + 1] = s[i] + a[i];
  int q;
  scanf("%d", &q);
  while (q--) {
    int l, r;
    scanf("%d%d", &l, &r);
    printf("%lld\n", s[r] - s[l]);
  }
  return 0;
}