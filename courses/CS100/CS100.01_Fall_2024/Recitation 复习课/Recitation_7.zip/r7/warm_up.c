#include <stdio.h>

#define MUL(a, b) a * b

int main() {
    int a;
    MUL(int, p = &) a;
    MUL(if(1), p) = 5;
    printf("%d\n", 0[p]);
    return 0;
}