---
marp: true
math: mathjax
paginate: true
style: |
  section::after {
    content: attr(data-marpit-pagination) '/' attr(data-marpit-pagination-total);
  }

  .columns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }

---

# Recitation 3 Code
## From Xiao Liu

---

# Exercise 1

Since `i` is defined globally, it is initialized with default value `0`. The `else` block is executed as the expression within `if` evalutes to `false`. Therefore, the `else` block gets executed.

---

# Exercise 2

Output:
```
func(1): case 1, case 2, case 3.
func(2): case 2, case 3.
func(3): case 3.
func(4): case 4, case 5 or case 6, default.
func(5): case 5 or case 6, default.
func(6): case 5 or case 6, default.
func(7): default.
func(8): default.
```

---

# Exercise 3

- Initially, `i = 0`. Since `case 0` is `true`, the value of `i` is updated to 5. However, because there is no `break` statement, the execution continues through the remaining cases, and `i` is updated to 16 by the last statement in the `switch` block.

- In the next iteration, no case evaluates to `true`, so the `default` case is executed, setting `i` to 21. 

- In C, once a `switch` statement encounters a `true` case, the subsequent cases are executed sequentially until a `break` statement is encountered. If no `break` is present, all cases following the `true` case are executed.

---

# Exercise 4

In a `for` loop, specifying the expressions is optional. The `>>=` operator is a compound assignment operator that shifts the binary representation of a value one position to the right, assigning the result back to the variable. The `for` loop continues executing until the value of the variable `i` becomes 0.

---

# Exercise 5

The program enters an infinite loop because the value of `n` never becomes zero when the loop condition `n != 0` is evaluated. The value of `n` decreases in the sequence: 9, 7, 5, 3, 1, -1, -3, -5, -7, -9, and so on.

---

# Exercise 6

The program contains a bug where the condition allows the `do-while` loop to execute even when `c = 0`. This is problematic because the increment operation is a post-increment, meaning the division by zero (`no / 0`) will result in undefined behavior.

> [CppReference: Arithmetic operators - Multiplicative operators - Division]  
> If the second operand of the division operator (`/`) is zero, the behavior is undefined, unless IEEE floating-point arithmetic is supported and floating-point division is taking place.

---

# Exercise 8.1

```c
#define MAX(A, B) A < B ? B : A
```
With this macro, every occurrence of `MAX(expr1, expr2)` is replaced with `expr1 < expr2 ? expr2 : expr1`.

```c
int i = 10, j = 15;
int k = MAX(i, j) + 1;
```

This expands to:
```c
int k = i < j ? j : i + 1; // i < j ? j : (i + 1)
```
The lack of parentheses around the macro arguments leads to ambiguity in expression evaluation.

---

# Exercise 8.2

```c
#define MAX(A, B) (A < B ? B : A)
```
Here, adding a single pair of parentheses around the whole expression provides some clarity, but is it enough?

```c
int i = 10, j = 15;
int k = MAX(i, i & j); // Comparing i and i & j
```
This expands to:
```c
int k = (i < i & j ? i & j : i); // (i < i) & j
```
Due to operator precedence, this becomes `(i < i) & j`, which is likely not the intended behavior. This demonstrates that one pair of parentheses does not fully address the issue.

---

# Exercise 8.3
```c
#define MAX(A, B) ((A) < (B) ? (B) : (A))
```
Adding parentheses around both arguments and the entire expression should resolve operator precedence issues.
```c
int i = 10, j = 15;
int k = MAX(i, ++j);
```
This expands to:
```c
int k = ((i) < (++j) ? (++j) : (i));
```
Here, `j` could be incremented twice, which results in unintended side effects. Although the operator precedence is correct, caution must be taken with macros involving expressions that have side effects, like `++`.

---

# Recitation 3 Code
## From Xiao Liu