# Local and Remote Repositories
  - Take me to [Video Tutorial](https://kodekloud.com/topic/local-and-remote-repositories/)
  
In this section, we will take a look at local and remote repositories

## Types of Repositories
- Git has two repository types
 - Local Repository
  - Local Repository is on your own machine, so you have direct access to it.
 - Remote Repository
   - Remote Repository is usually a centralized server.
  




