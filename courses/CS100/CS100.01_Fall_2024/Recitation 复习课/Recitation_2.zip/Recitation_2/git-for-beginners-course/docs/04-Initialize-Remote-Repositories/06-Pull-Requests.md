# Pull Requests
  - Take me to [Video Tutorial](https://kodekloud.com/topic/pull-requests/)
   
In this section, we will take a look at Pull requests


To push the latest changes to github sarah branch
```
$ git push origin sarah
```

To push changes from sarah to master we have to open something called **`Pull Request`**

  ![pull1](../../images/pull1.PNG)

  ![pull2](../../images/pull2.PNG)

  ![pull3](../../images/pull3.PNG)
  



