  # Lab - Introduction
   - Take me to [Video Tutorial](https://kodekloud.com/topic/lab-introduction/)


