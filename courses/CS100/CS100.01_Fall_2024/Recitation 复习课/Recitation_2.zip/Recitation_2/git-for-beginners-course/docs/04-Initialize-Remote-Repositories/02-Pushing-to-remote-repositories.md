 # Pushing to remote repositories
   - Take me to [Video Tutorial](https://kodekloud.com/topic/pushing-to-remote-repositories/)
   
 In this section, we will take a look at pushing to remote repositories
 
 #### In order to keep our local and remote repo in sync, we have to push the data from local repo to remote repo
 - To push data from local to remote repo
   ```
   $ git push origin master
   ```
   
   ![gpush](../../images/gpush.PNG)
   
   
