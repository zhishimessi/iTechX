# Git Course Introduction
  - Take me to [Video Tutorial](https://kodekloud.com/topic/git-course-introduction/)
