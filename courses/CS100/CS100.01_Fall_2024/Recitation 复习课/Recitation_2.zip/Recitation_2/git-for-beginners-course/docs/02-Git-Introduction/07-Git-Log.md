# Git Log
  - Take me to [Video Tutorial](https://kodekloud.com/topic/git-log/)
  
To know about other commits information such as commit hash, the author name and the date
```
$ git log
```
 ![gitlog](../../images/gitlog.PNG)
  
To easily show commit details as one line
```
$ git log --oneline
```

 ![gitlog1](../../images/gitlog1.PNG)
  


