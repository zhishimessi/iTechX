---
marp: true
math: mathjax
paginate: true
style: |
  section::after {
    content: attr(data-marpit-pagination) '/' attr(data-marpit-pagination-total);
  }

  .columns {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }

---

# Recitation 6 Code

## From Xiao Liu

---

# Exercise 1

Since `i` is defined globally, it is initialized with default value `0`. The `else` block is executed as the expression within `if` evalutes to `false`. Therefore, the `else` block gets executed.

---

# Details of `if constexpr`

```cpp
#include <iostream>
#include <type_traits>

template <typename T>
void printType(T value) {
    if constexpr (std::is_integral<T>::value) {
        std::cout << value << " is an integer." << std::endl;
    } else {
        std::cout << value << " is not an integer." << std::endl;
    }
}

int main() {
    printType(42);        // Output: 42 is an integer.
    printType(3.14);      // Output: 3.14 is not an integer.
    printType("Hello");   // Output: Hello is not an integer.

    return 0;
}
```

---

# Details of `if constexpr` (cont.)

```cpp
template <typename T>
void printType(T value) {
    if constexpr (std::is_integral<T>::value) {
        std::cout << value << " is an integer." << std::endl;
    } else {
        std::cout << value << " is not an integer." << std::endl;
    }
}
```
- **`if constexpr`**: This condition is evaluated at compile time, meaning it will eliminate the unused branches based on the type of the argument.
- `std::is_integral<T>::value` checks if the type `T` is an integer type. If it is, it prints "is an integer"; otherwise, it prints "is not an integer."

The key benefit of `if constexpr` is that only the code corresponding to the evaluated condition will be compiled, leading to more efficient code.

---

# Details of "Fold Expressions"

- [CppReference - Fold expressions](https://en.cppreference.com/w/cpp/language/fold)

```cpp
#include <iostream>

template <typename... Args>
auto sum(Args... args) {
    return (args + ...);  // Fold expression: applies '+' to all arguments
}

int main() {
    std::cout << sum(1, 2, 3, 4, 5) << std::endl;  // Output: 15
    std::cout << sum(10, -5, 3) << std::endl;     // Output: 8
    return 0;
}
```

---

# Details of "Fold Expressions" (cont.)

```cpp
#include <iostream>

class MyClass {
public:
    MyClass(int val) : value(val) {}
    int value;
};

template <typename... Args>
auto sumValues(Args... args) {
    return (args.value + ...);  // Sum the 'value' member of all objects
}

int main() {
    MyClass obj1(5), obj2(10), obj3(15);
    std::cout << sumValues(obj1, obj2, obj3) << std::endl;  // Output: 30
    return 0;
}
```

---

# Another Example of Functional-Style Cast
```cpp
#include <iostream>

class Point {
public:
    int x, y;
    // Constructor to initialize the point with x and y values
    Point(int x, int y) : x(x), y(y) {}
};

int main() {
    // Using constructor-style cast with an expression-list
    Point p = Point{1, 2};  // Equivalent to: Point p(1, 2);
    
    std::cout << "Point: (" << p.x << ", " << p.y << ")" << std::endl;

    return 0;
}
```

---

# Exercise 2

```cpp
#include <iostream>
#include <vector>

int main(){
  std::vector vec(5, 42);
  for(auto i : vec)
    std::cout << i << std::endl;
}
```

<div class="columns">
<div class="columns-left">

- `vec`: `std::vector<int>`

- `i`: int

</div>
<div class="columns-right">

Output:
```bash
42
42
42
42
42
```
</div>
</div>

---

# Recitation 6 Code

## From Xiao Liu
