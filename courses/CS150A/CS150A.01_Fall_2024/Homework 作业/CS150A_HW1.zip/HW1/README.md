# CS150A HW1

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (100 PTS)

+ Finish the problems in `HW1_writing.pdf` or `HW1_writing.tex`.

### Part Two: Coding (100 PTS)

+ Finish `HW1_coding.ipynb`.

**IMPORTANT:** If you submit pdf without outputs, we will impose a penalty deduction on the grade.

After completion, you should convert your writing and coding part to PDF files, and concatenate the writing and the coding part into **one PDF** and upload it to **blackboard**.

## Due date

23:59, 2024.10.31.
