# CS150A HW2

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (100 PTS)

1. Finish the problems in `HW2_writing.pdf` or `HW2_writing.tex`.
2. Upload the pdf version of your answers to Gradescope.

### Part Two: Coding (100 PTS)
In homework 2, you need to finish hw2_coding.ipynb.

*Caution: Activity-15.ipynb is recommended to complete but not necessary. What
you need is to fill out the required content of hw2_coding.ipynb.*

1. Finish `hw2_coding.ipynb` following the instructions at its top. 
2. Upload the pdf version of `hw2_coding.ipynb` to gradescope.

**IMPORTANT:** If you submit pdf without outputs, we will impose a penalty deduction on the grade.

## Due date: 23:59 (CST), May. 3, 2024


