# CS150A HW1

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (100 PTS)

1. Finish the problems in `HW1_writing.pdf` or `HW1_writing.tex`.
2. Upload the pdf version of your answers to Gradescope.

### Part Two: Coding (100 PTS)

1. Finish `HW1_coding.ipynb`. 
2. Upload the pdf version of your code **with outputs** to Gradescope.

**IMPORTANT:** If you submit pdf without outputs, we will impose a penalty deduction on the grade.

## Due date

23:59, 2024.4.5.
