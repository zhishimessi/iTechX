# CS150A HW3

## Introduction

HW3 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (100 pts)

1. Finish the problems in `HW3_writing.pdf` or `HW3_writing.tex`.
2. Upload the pdf version of your answers to Gradescope.

### Part Two: Coding (100 pts)

1. Finish `HW3_coding.ipynb`. 
2. Upload the pdf version of your code **with outputs** to Gradescope.

**IMPORTANT:** If you submit pdf without outputs, we will impose a penalty deduction on the grade.

## Due date: 23:59 (CST), Jun. 9, 2024
