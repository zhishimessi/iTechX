import numpy as np
def QP_solver(A1,A2,b1,b2,g,H):
    ###TODO###
    x=None
    return x