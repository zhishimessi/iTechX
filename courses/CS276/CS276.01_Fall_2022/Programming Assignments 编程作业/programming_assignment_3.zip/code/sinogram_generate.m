clear;
close;

% configuration for fan-beam geometry
num_angle = 90;
SOD = 380; 
dsensor = 0.1;

% gt
img = niftiread('gt.nii');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     TODO: Implement FBP here                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                        END OF YOUR CODE                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

niftiwrite(sino, ['proj_', num2str(num_angle), '.nii']);
niftiwrite(sensor_pos, 'proj_pos.nii');