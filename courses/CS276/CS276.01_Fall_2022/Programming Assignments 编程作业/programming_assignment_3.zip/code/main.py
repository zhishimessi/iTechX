import torch
import numpy as np
import dataset
from tqdm import tqdm
import SimpleITK as sitk
import commentjson as json
from torch.utils import data
from torch.optim import lr_scheduler

def train(config_path):

    # load config
    # -----------------------
    with open(config_path) as config_file:
        config = json.load(config_file)

    # file
    # -----------------------
    proj_data_dir = config["file"]["proj_data_dir"]
    proj_pose_data_dir = config["file"]["proj_pose_data_dir"]
    h, w, SOD = config["file"]["h"], config["file"]["w"], config["file"]["SOD"]
    num_angle, num_det = sitk.GetArrayFromImage(sitk.ReadImage(proj_data_dir)).shape

    # parameter
    # -----------------------
    lr = config["train"]["lr"]
    gpu = config["train"]["gpu"]
    epoch = config["train"]["epoch"]
    save_epoch = config["train"]["save_epoch"]
    lr_decay_epoch = config["train"]["lr_decay_epoch"]
    lr_decay_coefficient = config["train"]["lr_decay_coefficient"]
    batch_size = config["train"]["batch_size"]
    num_sample_ray = config["train"]["num_sample_ray"]

    # data loader
    # -----------------------
    train_loader = data.DataLoader(
        dataset=dataset.TrainData(proj_path=proj_data_dir, proj_pos_path=proj_pose_data_dir,
                                  num_sample_ray=num_sample_ray, num_angle=num_angle, SOD=SOD),
        batch_size=batch_size,
        shuffle=True)
    test_loader = data.DataLoader(
        dataset=dataset.TestData(h=(2*SOD), w=(2*SOD)),
        batch_size=1,
        shuffle=False)

    # model
    # -----------------------
    device = torch.device('cuda:{}'.format(str(gpu) if torch.cuda.is_available() else 'cpu'))

    #############################################################################
    # TODO: Define your neural network and loss function here                   #
    # Hint: Use hash encoding and try different loss functions                  #
    #############################################################################
    network = None
    loss_func = None
    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################

    optimizer = torch.optim.Adam(params=network.parameters(), lr=lr)
    scheduler = lr_scheduler.StepLR(optimizer, step_size=lr_decay_epoch, gamma=lr_decay_coefficient)

    loop_tqdm = tqdm(range(epoch), leave=False)
    for e in loop_tqdm:

        #############################################################################
        # TODO: Implement the training and testing processes here                   #
        #############################################################################
        pass
        #############################################################################
        #                             END OF YOUR CODE                              #
        #############################################################################

if __name__ == '__main__':
    train('config.json')