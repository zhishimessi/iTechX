import torch
import time
import numpy as np
import matplotlib.pyplot as plt

from tqdm import tqdm
from einops import rearrange
from torch import nn
from torch import optim

from nlos_dataloader import NlosPoseDataset
from torch.utils.data import DataLoader
from layers import L2JointLocationLoss   # TODO 3.2


from cpa3_config import _C as cfg


def seed_everything(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


def train(model, dataloader, criterion, optimizer, cfg, epoch):

    model.train()

    for step, (input, target_joints) in enumerate(dataloader):

        input = input.to(cfg.DEVICE)
        output = model(input)

        target_joints = rearrange(
            target_joints, 'b n d -> b (n d)').to(cfg.DEVICE)
        target_weights = torch.ones_like(target_joints).to(cfg.DEVICE)
        loss = criterion(output, target_joints, target_weights)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


def make(cfg):
    train_dataset = NlosPoseDataset(cfg=cfg, datapath=cfg.DATASET.TRAIN_PATH)
    train_dataloader = DataLoader(train_dataset, batch_size=cfg.TRAIN.BATCH_SIZE, shuffle=True,
                                  num_workers=cfg.NUM_WORKERS)
    model = NlosPose(cfg)
    model = model.to(cfg.DEVICE)
    criterion = L2JointLocationLoss(output_3d=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(
        model.parameters(),
        lr=cfg.TRAIN.LR
    )

    return model, train_dataloader, criterion, optimizer


def run():

    seed_everything(23333)

    model, train_dataloader, criterion, optimizer = make(cfg)

    for epoch in tqdm(range(cfg.TRAIN.BEGIN_EPOCH, cfg.TRAIN.END_EPOCH)):
        train(model, train_dataloader, criterion, optimizer, cfg, epoch)

    print("finished")


if __name__ == '__main__':
    run()
