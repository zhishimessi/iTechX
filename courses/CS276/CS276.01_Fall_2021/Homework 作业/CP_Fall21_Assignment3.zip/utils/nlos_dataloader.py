import os
import sys
import cv2
import numpy as np

from torch.utils.data import Dataset, DataLoader
from scipy.ndimage import zoom
from einops import rearrange


class NlosPoseDataset(Dataset):
    """docstring for NlosPoseDataset"""

    def __init__(self, cfg, datapath):
        super().__init__()
        self.num_joints = cfg.DATASET.NUM_JOINTS
        self.heatmap_size = cfg.DATASET.HEATMAP_SIZE

        self.measFiles = []
        self.jointsFiles = []
        self.measPath = os.path.join(datapath, 'meas')
        self.jointsPath = os.path.join(datapath, 'joints')
        measNames = os.listdir(self.measPath)
        for measName in measNames:
            assert os.path.splitext(measName)[1] == '.hdr', \
                f'Data type should be .hdr,not {measName} in {self.measPath}'
            fileName = os.path.join(self.measPath, measName)
            self.measFiles.append(fileName)
            jointsName = os.path.join(
                self.jointsPath, os.path.splitext(measName)[0] + '.joints')
            assert os.path.isfile(jointsName), \
                f'Do not have related joints {jointsName}'
            self.jointsFiles.append(jointsName)

    def __getitem__(self, index):
        measFile = self.measFiles[index]
        jointFile = self.jointsFiles[index]
        try:
            meas = cv2.imread(measFile, -1)
            meas = meas / np.max(meas)
            meas = cv2.cvtColor(meas, cv2.COLOR_BGR2GRAY)
            meas = meas / np.max(meas)
        except TypeError:
            measFile = self.measFiles[0]
            jointFile = self.jointsFiles[0]

            meas = cv2.imread(measFile, -1)
            meas = meas / np.max(meas)
            meas = cv2.cvtColor(meas, cv2.COLOR_BGR2GRAY)
            meas = meas / np.max(meas)
            print(
                f'--------------------\nNo.{index} meas is TypeError. \n--------------------------\n')
        except:
            measFile = self.measFiles[0]
            jointFile = self.jointsFiles[0]

            meas = cv2.imread(measFile, -1)
            meas = meas / np.max(meas)
            meas = cv2.cvtColor(meas, cv2.COLOR_BGR2GRAY)
            meas = meas / np.max(meas)
            print(
                f'--------------------\nNo.{index} meas is wrong. \n--------------------------\n')

        joints = np.loadtxt(jointFile)
        # coord to box
        meas = rearrange(meas, '(t h) w ->t h w', t=600)
        meas = meas[:512, :, :]

        joints[:, 0] = (joints[:, 0] + 0.5) * self.heatmap_size[0]
        joints[:, 1] = (joints[:, 1] + 0.5) * self.heatmap_size[1]
        joints[:, 2] = (joints[:, 2] + 0.5) * self.heatmap_size[2]
        meas = rearrange(meas, 't h w-> 1 t h w')

        return meas, joints

    def __len__(self):
        return len(self.measFiles)


if __name__ == '__main__':

    testDataLoader = True
    if testDataLoader:
        datapath = r'e:\Users\LP\Desktop\cpa3_2021\data\train'
        import sys
        print(sys.path)
        sys.path.append(r'D:\LPP\nlospose_test\models')
        from cpa3_config import _C as cfg
        train_data = NlosPoseDataset(cfg, datapath)
        trainloader = DataLoader(train_data, batch_size=2, shuffle=True)

        print(type(trainloader))
        dataiter = iter(trainloader)
        meas, joints = dataiter.next()
        print(f'meas\' type is {type(meas)}:\n{meas.shape}\n----------------')
        print(
            f'joints\' type is {type(joints)}:\n{joints.shape}\n----------------')
