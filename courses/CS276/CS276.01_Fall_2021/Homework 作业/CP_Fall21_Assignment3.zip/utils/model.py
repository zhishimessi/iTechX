import torch
from torch import nn
from einops import rearrange

from config import _C as cfg
from layers import light_cone_transform, project, pose_net


class NlosPose(nn.Module):
    def __init__(self, cfg):
        super().__init__()

        self.time_begin = 0
        self.time_end = cfg.MODEL.TIME_SIZE // cfg.MODEL.DOWNSAMPLE_RATIO

        self.light_cone_transform = light_cone_transform(
            wall_size=cfg.MODEL.WALL_SIZE,
            bin_resolution=cfg.MODEL.BIN_RESOLUTION,
            image_size=cfg.MODEL.IMAGE_SIZE,
            time_size=cfg.MODEL.TIME_SIZE,
        )

        self.project = project(basedim=3)

        self.pose_net_cfg = get_pose_config()
        self.pose_net = pose_net(self.pose_net_cfg)

    def forward(self, meas):

        meas = self.feature_extraction(meas)

        feature_3d = self.light_cone_transform(meas)  # TODO 1

        feature_2d = self.project(feature_3d)  # TODO 2

        output = self.pose_net(feature_2d)  # TODO 3.1

        return output


if __name__ == '__main__':

    from models.config import _C as cfg
    model = NlosPose(cfg)
    video = torch.randn(1, 1, cfg.MODEL.TIME_SIZE,
                        cfg.MODEL.IMAGE_SIZE[0], cfg.MODEL.IMAGE_SIZE[1])
    pre = model(video)
