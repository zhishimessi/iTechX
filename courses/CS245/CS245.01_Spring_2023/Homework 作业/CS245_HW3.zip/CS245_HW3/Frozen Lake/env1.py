import gym
import matplotlib.pyplot as plt

# Create an 10x10 Frozen Lake environment
map =  [
        "SFFFFFFHFH",
        "HFFFFFHFFF",
        "FFFHFFFFFF",
        "FFHFFHFFFF",
        "FFFFFFFFFF",
        "FHFHFFHFFF",
        "FFFFHFFFFF",
        "FFFFFFHFFF",
        "FFHFFFFFFF",
        "FFFFFFHFFG",
    ]
env = gym.make('FrozenLake-v1', desc=map,is_slippery=False)

n_actions = env.action_space.n
n_states = env.observation_space.n

#Random example
accumulated_reward = []
total_reward = 0
num_episodes = 100000

for episode in range(num_episodes):
    state,_ = env.reset()
    done = False

    while not done:
        action = env.action_space.sample()

        next_state, reward, done, _, _ = env.step(action)

        state = next_state

        total_reward += reward
    accumulated_reward.append(total_reward)

env.close()

plt.plot(accumulated_reward, label='reward')
plt.grid()
plt.legend()
plt.show()
