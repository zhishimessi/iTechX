from environment import *
import matplotlib.pyplot as plt

env = RiceData()
RanAlg = RandomAlg(3)
Rregret = [0]

for i in range(10000):
    context, rwd = env.step()
    R_arm = RanAlg.take_action()
    Rregret += [Rregret[-1] + 1 - rwd[R_arm]]

plt.plot(Rregret, label='Random')
plt.grid()
plt.legend()
plt.show()