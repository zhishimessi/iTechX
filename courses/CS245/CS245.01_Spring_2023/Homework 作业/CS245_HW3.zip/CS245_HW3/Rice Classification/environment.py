import pandas as pd
import numpy as np
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

RiceData = pd.read_excel('RiceData.xlsx')
RiceData.fillna(0, inplace=True)
dictForClasses = {k: v for k, v in zip(list(set(RiceData.iloc[:, -1].tolist())),list(range(len(list(set(RiceData.iloc[:, -1].tolist()))))))}

for i in range(10000):
    classes = dictForClasses[RiceData.iloc[i, -1]]
    RiceData.loc[i, 'CLASS'] = classes

X = np.array(RiceData.iloc[:, 0:50])
y = np.asarray(RiceData.iloc[:, -1]).astype('int64')
X2 = np.array(RiceData.iloc[:, 0:20])

class RiceData():
    def __init__(self):
        self.arm = 5
        self.dim = 250
        self.X = X
        self.y = y
        self.round = 0

    def step(self):
        x = self.X[self.round]
        X_n = []
        for i in range(self.arm):
            front = np.zeros((50 * i))
            back = np.zeros((50 * (self.arm - 1 - i)))
            new_d = np.concatenate((front, x, back), axis=0)
            X_n.append(new_d)
        X_n = np.array(X_n)
        reward = np.zeros(self.arm)
        # print(target)
        reward[y[self.round]] = 1
        self.round += 1
        return X_n, reward

class RandomAlg:
    def __init__(self,K):
        self.K = K
    def take_action(self):
        return np.random.choice(self.K)

