import gym
import matplotlib.pyplot as plt

# Create an 10x10 Frozen Lake environment
env = gym.make('CliffWalking-v0')

n_actions = env.action_space.n
n_states = env.observation_space.n

#Random example
accumulated_reward = []
total_reward = 0
num_episodes = 1000

for episode in range(num_episodes):
    state,_ = env.reset()
    done = False

    while not done:
        action = env.action_space.sample()

        next_state, reward, done, _, _ = env.step(action)

        state = next_state

        total_reward += reward
    accumulated_reward.append(total_reward)
    total_reward = 0

env.close()

plt.plot(accumulated_reward, label='reward')
plt.grid()
plt.legend()
plt.show()
