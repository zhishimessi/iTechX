import gym
import matplotlib.pyplot as plt
import random

env = gym.make('CliffWalking-v0')

def take_action(action):
    if random.random() < 0.33:
        return action
    else:
        vertical_actions = [0, 2] if action in [1, 3] else [1, 3]
        return random.choice(vertical_actions)

n_actions = env.action_space.n
n_states = env.observation_space.n

#Random example
accumulated_reward = []
total_reward = 0
num_episodes = 1000

for episode in range(num_episodes):
    state,_ = env.reset()
    done = False

    while not done:
        action = take_action(env.action_space.sample()) #Employ the 'take_action' function to introduce randomness

        next_state, reward, done, _, _ = env.step(action)

        state = next_state

        total_reward += reward
    accumulated_reward.append(total_reward)
    total_reward = 0

env.close()

plt.plot(accumulated_reward, label='reward')
plt.grid()
plt.legend()
plt.show()