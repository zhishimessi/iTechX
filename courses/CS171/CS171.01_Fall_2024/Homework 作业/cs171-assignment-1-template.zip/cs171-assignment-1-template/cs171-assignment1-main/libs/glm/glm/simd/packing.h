/// @ref simd
/// @file glm/simd/packing.h

#ifndef LIBS_GLM_GLM_SIMD_PACKING_H_
#define LIBS_GLM_GLM_SIMD_PACKING_H_

#if GLM_ARCH & GLM_ARCH_SSE2_BIT

#endif//GLM_ARCH & GLM_ARCH_SSE2_BIT
#endif  // LIBS_GLM_GLM_SIMD_PACKING_H_