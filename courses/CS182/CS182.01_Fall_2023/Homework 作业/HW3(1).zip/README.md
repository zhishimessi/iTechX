# CS182 HW3

## Introduction

HW3 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (40 PTS)

1. Finish the problems in `writing/hw3_writing.pdf`.
2. Upload your answers as "yourname_hw3_writing.pdf" to Gradescope.

### Part Two: Coding (60 PTS)

1. Finish `coding/hw3_mixtures_of_gaussians_EM.ipynb`. 
2. Please export the jupyter notebook as a PDF named  "yourname_hw3_coding.pdf" and upload it to Gradescope.

## Due date

Tuesday Nov. 30 at 23:59 (CST)