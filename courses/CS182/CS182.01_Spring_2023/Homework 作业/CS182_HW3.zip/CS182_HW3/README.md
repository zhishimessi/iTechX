# CS182 HW2

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (60 PTS)

1. Finish the problems in `writing/CS182_HW3_writing.pdf`.
2. Upload your answers as "name_HW3_writing.pdf" to BlackBoard.

### Part Two: Coding (40 PTS)

1. Finish `coding/CS182_HW3_coding.ipynb`. 
2. Transform the finished `CS182_HW3_coding.ipynb` file as `name_HW3_coding.pdf`
3. Zip both "name_HW3_coding.pdf" and the .pdf file for writing
4. Uplaod the "name_HW3.zip" to BlackBoard.

## Due date
 
Due Tuesday, April. 18 at 11:59pm (CST)
