# CS182 HW5

## Introduction

HW5 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (50 PTS)

1. Finish the problems in `writing/hw5_writing.pdf`.
2. Save your answers as "name_hw5_writing.pdf"

### Part Two: Coding (50 PTS)

1. Finish `coding/hw5_coding.ipynb`. 
2. Transform the finished `hw5_coding.ipynb` file as `name_hw5_coding.pdf`

### Submit HW
Finally, uplaod all .pdf files to BB

## Due date
 
Due Tues, May 23 at 11:59pm (CST)
