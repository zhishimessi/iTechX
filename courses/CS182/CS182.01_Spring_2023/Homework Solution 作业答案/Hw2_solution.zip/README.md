# CS182 HW2

## Introduction

HW1 consists of two parts: writing exercises and coding exercises.

### Part One: Writing (40 PTS)

1. Finish the problems in `writing/hw2_writing.pdf`.
2. Save your answers as "name_hw2_writing.pdf"

### Part Two: Coding (60 PTS)

1. Finish `coding/hw2_coding.ipynb`. 
2. Transform the finished `hw2_coding.ipynb` file as `name_hw2_coding.pdf`

### Submit HW
1. Zip both "name_hw1_coding.pdf" and the .pdf file for writing
2. Finally, uplaod the "name_hw2.zip" to BB

## Due date
 
Due Thurs, Mar. 23 at 11:59pm (CST)
