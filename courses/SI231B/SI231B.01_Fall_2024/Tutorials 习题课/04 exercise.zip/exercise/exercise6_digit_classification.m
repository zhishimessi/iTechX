clear;
clc;
numTrain = 100; numTest = 100;
d = load('mnist.mat');
X = d.trainX;
Y = d.trainY;
A = d.testX;
B = d.testY;

digitSpace = zeros([256, numTrain, 10]);
position = ones([1,10]);
i = 0;
while i<(numTrain*10)
    pos = randi(60000);
    digit = Y(1, pos);
    image = reshape(X(pos,:), 28, 28)';
    imageVec = ImageCrop2(image);
    if position(1,digit+1) <= numTrain
        digitSpace(:,position(1,digit+1),digit+1) = imageVec;
        position(1,digit+1)=position(1,digit+1)+1;
        i = i + 1;
    end
end


pos = randi(100);
unknown = reshape(A(pos,:), 28, 28)';
vv = double(ImageCrop2(unknown));
res = zeros([1, 10]);
for digit = 0:9
    % TODO 1: Compute the SVD of each digitSpace
    % TODO 2: Compute the residual of orthogonal basis and the unknown vector
end
value = find(res==min(res));
value = value - 1;

figure();
imshow(unknown, 'InitialMagnification', 1000), title(sprintf('predict by SVD: %d', value));


function [res] = residual(basis,rank,vector)
proj = 0;
for i = 1: rank
    % TODO: add the compute of residual
end
end


function [vector] = ImageCrop2(matrix)
[row, col] = size(matrix);
sumCol = sum(matrix,1);
Left = 0;

for i = 1: col
    if sumCol(i)>0
        Left = i;
        break;
    end
end

sumRow = sum(matrix,2);
Up = 0;
for i = 1: row
    if sumRow(i)>0
        Up = i;
        break;
    end
end

sumCol = sum(matrix, 1) ;
Right = 0;
for i = col:-1:1
    if sumCol(i)>0
        Right = i;
        break;
    end
end

sumRow = sum(matrix,2);
Bottom = 0;
for i = row:-1:1
    if sumRow(i)>0
        Bottom = i;
        break;
    end
end

I = matrix;
I2 = imcrop(I,[Left Up Right-Left Bottom-Up]);
I3 = imresize(I2, [16, 16]);
vector = I3(:);
end

