clear;
clc;

% Generate matrix
m = 10; n = 5;
A = rand(m,n);
A0 = A;
[U_r, S_r, V_r] = svd(A);

disp(['error of SVD in matlab: ',num2str(norm(U_r*S_r*V_r'-A0, "fro"))]);

[U_j, S_j, V_j] = svd_jw(A);
disp(['error of SVD via Jordan-Wielandt matrix: ',num2str(norm(U_j*S_j*V_j'-A0, "fro"))]);


function [U_j, S_j, V_j] = svd_jw(A)
[m, n] = size(A);
U_j = zeros(m,n);
S_j = zeros(n,n);
V_j = zeros(n,n);

% TODO 1: form J
% TODO 2: Write the symmetric QR iteration here


end