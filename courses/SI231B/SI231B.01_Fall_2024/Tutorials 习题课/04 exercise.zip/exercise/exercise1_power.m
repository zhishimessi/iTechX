clear;
clc;
% Generate matrix
m = 10; n = 5;
A = rand(m,n);
A0 = A;
[U_r, S_r, V_r] = svd(A);

disp(['error of SVD in matlab: ',num2str(norm(U_r*S_r*V_r'-A0, "fro"))])

% SVD via power iteration
[U_p, S_p, V_p] = svd_power(A);
disp(['error of SVD via power iteration: ',num2str(norm(U_p*S_p*V_p'-A0, "fro"))]);

function [U_p, S_p, V_p] = svd_power(A)
[m, n] = size(A);
U_p = zeros(m,n);
S_p = zeros(n,n);
V_p = zeros(n,n);


for s_index = 1:n
    % TODO: write the power iteration code
end

end