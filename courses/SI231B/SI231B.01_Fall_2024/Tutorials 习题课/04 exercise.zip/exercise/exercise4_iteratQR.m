clear;
clc;

% Generate matrix
m = 10; n = 5;
A = rand(m,n);
A0 = A;
[U_r, S_r, V_r] = svd(A);
disp(['error of SVD in matlab: ',num2str(norm(U_r*S_r*V_r'-A0, "fro"))]);

[U_qr, S_qr, V_qr] = svd_qr(A);
disp(['error of SVD via iterative QR: ',num2str(norm(U_qr*S_qr*V_qr'-A0, "fro"))]);


function [U_qr,S_qr,V_qr] = svd_qr(A)

tol=eps*1024;
sizea=size(A);
loopmax=100*max(sizea);
loopcount=0;


U_qr=eye(sizea(1));
S_qr=A';
V_qr=eye(sizea(2));

Err=realmax;
while Err>tol && loopcount<loopmax

    % fill your code use qr() function here

    % exit when we get "close"
    e=triu(S_qr,1);
    E=norm(e(:));
    F=norm(diag(S_qr));
    if F==0, F=1;end
    Err=E/F;
    loopcount=loopcount+1;
end
% [Err/tol loopcount/loopmax]

%fix the signs in S
ss=diag(S_qr);
S_qr=zeros(sizea);
for n=1:length(ss)
    ssn=ss(n);
    S_qr(n,n)=abs(ssn);
    if ssn<0
       U_qr(:,n)=-U_qr(:,n);
    end
end

if nargout<=1
   U_qr=diag(S_qr);
end
end