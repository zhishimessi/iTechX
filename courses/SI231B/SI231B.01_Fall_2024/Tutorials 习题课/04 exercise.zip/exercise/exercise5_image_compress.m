CompressImage("1.jpg");
function [output_args] = CompressImage(filename)
%open an image
image = rgb2gray(imread(filename));
image = im2double(imresize(image,1));


%display the original image
figure();
imshow(image, 'InitialMagnification',100), title(sprintf(('Original Image')));
ranks = [320, 80, 20, 10, 5];

% TODO: Use SVD decomposition on iamge
for i=1:length(ranks)

    
    %calculate the compressed image
    approx_image=U*compressed_S*V';
    
    %display the compressed image
    figure();
    imshow(approx_image,'InitialMagnification',200) , title(sprintf('Rank % d Image', ranks(i)));

end

end