clear;
clc;
A = [3, 2;
    1, 4;
    0.5, 0.5;];
% Generate matrix
A0 = A;
[U_r, S_r, V_r] = svd(A);

disp(['error of SVD in matlab: ',num2str(norm(U_r*S_r*V_r'-A0, "fro"))])
[m, n] = size(A);
U = zeros(m,n);
S = zeros(n,n);
V = zeros(n,n);

% TODO: write the QR itearion code
% hint: for the first step eigen decomposition, you can use the eig()


disp(['error of SVD in QR: ',num2str(norm(U*S*V'-A0, "fro"))]);