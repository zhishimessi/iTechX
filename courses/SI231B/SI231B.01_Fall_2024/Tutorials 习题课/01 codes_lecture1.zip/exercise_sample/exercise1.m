clear;
clc;
% A = L * U

A = [2, 2, -2;
     4, 7, 7;
    6, 18, 22];
n = size(A, 1);

for k = 1 : n-1
    %write LU decomposition code
end

A
L
U

