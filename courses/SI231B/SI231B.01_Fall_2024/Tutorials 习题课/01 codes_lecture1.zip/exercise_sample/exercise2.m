clear;
clc;
%
% A(p,:) = L * U
%

A = [1,2, 4, 17;
     3, 6,-12, 3;
    2,3, -3, 2;
    0,2,-2,6];
n = size(A, 1);


p = 1 : n;

for k = 1 : n-1
    % wirte partial pivoting code

end

A
p

%check P*A=L*U
A = [1,2, 4, 17;
     3, 6,-12, 3;
    2,3, -3, 2;
    0,2,-2,6];
[L, U, P] = lu(A)