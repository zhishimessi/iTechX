% Generate a symmetric positive definite matrix A and a vector b
n = 100;
A = rand(n);
A = 0.5 * (A + A'); % Symmetrize the matrix
A = A + n * eye(n); % Make it positive definite
b =n*rand(n, 1);
eig(A)

% Set parameters
max_iter = 100;
omega = 1.2; % Relaxation factor for SOR

% Compute the exact solution using MATLAB's backslash operator

% Plot the errors


% Jacobi Iteration
function [x, errors] = jacobi(A, b, x_exact, max_iter, x_inital)
    n = length(b);
    x = x_inital; % Initial guess
    errors = zeros(max_iter, 1);
    for k = 0:max_iter-1
       %write the updates of Jacobi iterations
    end
end


% Gauss-Seidel Iteration
function [x, errors] = gauss_seidel(A, b, x_exact,  max_iter,x_inital)
    n = length(b);
    x = x_inital; % Initial guess
    errors = zeros(max_iter, 1);
    for k = 1:max_iter
         %write the updates of Gauss iterations
    end
end

% SOR Iteration
function [x, errors] = sor(A, b, x_exact, max_iter, omega,x_inital)
    n = length(b);
     x = x_inital; % Initial guess
    errors = zeros(max_iter, 1);
    for k = 1:max_iter
         %write the updates of SOR iterations
    end
end
