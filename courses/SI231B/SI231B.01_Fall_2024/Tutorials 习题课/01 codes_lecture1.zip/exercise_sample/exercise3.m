
clear;
clc;
%
A = [1, 4, 5;
     4, 18, 26;
    5, 26, 30];
n = size(A, 1);

%LDL decomposition
  L = eye(n); 
    d = zeros(n,1);
    v = zeros(n,1);
  %write LUD decomposition code

L
D
%check
L*D*L'
  
