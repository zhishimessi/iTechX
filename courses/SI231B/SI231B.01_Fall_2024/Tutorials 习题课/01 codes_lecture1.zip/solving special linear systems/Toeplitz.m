function ShowToeplitz()
% function ShowToeplitz()
% Examines the Toeplitz algorithms Durbin, Levinson, and Trench
% on a small random example.
% Generate T...
n = 5
T = gallery('toeppd',n)
T = T/T(1,1);
r = T(2:n,1);
clc
disp('T = ')
fprintfM('%7.3f',T);
r(n) = rand(1);
y = Durbin(r);
fprintf('||Durbin(r)  - T\\(-r)|| = %10.3e\n',norm(y-T\(-r)))
b = randn(n,1);
x = Levinson(r,b);
fprintf('||Levinson(r,b) - T\\b|| = %10.3e\n',norm(x-T\b))
B = Trench(r);
fprintf('\nInverse of T = \n')
fprintfM('%7.3f',B)
fprintf('\n||Trench(r) - inv(T)|| = %10.3e\n',norm(B-inv(T)))

%% Durbin
function y = Durbin(r)
% function y = Durbin(r)
% Yule-Walker system solver.
% r is nx1 such that T = toeplitz([1;r(1:n-1)]) is positive definite
% y is nx1 and solves Ty = -r(n-1:-1:1)
% GVL4: Algorithm 4.7.1
n = length(r); 
y = zeros(n,1); 
z = zeros(n,1);
y(1) = -r(1); 
beta = 1; 
alfa = -r(1);
for k=1:n-1
    beta     = (1 - alfa^2)*beta;
    alfa     = -(r(k+1)+r(k:-1:1)'*y(1:k))/beta;
    z(1:k)   = y(1:k) + alfa*y(k:-1:1);
    y(1:k+1) = [z(1:k);alfa];
end

%% Levinson
function x = Levinson(r,b)
% function y = Levinson(r,b)
% Symmetric positive definite Toeplitz system solver.
% r is nx1 such that T = toeplitz([1;r(1:n-1)]) is positive definite and
%    b is nx1.
% x is nx1 and solves Tx = b.
% GVL4: Algorithm 4.7.2
n = length(b); 
y = zeros(n,1); 
v = zeros(n,1); 
z = zeros(n,1); 
x = zeros(n,1);
y(1)=-r(1); 
x(1) = b(1); 
beta = 1; 
alfa = -r(1);
for k=1:n-1
    beta = (1-alfa^2)*beta;
    mu = (b(k+1)-r(1:k)'*x(k:-1:1))/beta;
    v(1:k) = x(1:k)+ mu*y(k:-1:1);
    x(1:k+1) = [v(1:k);mu];
    if k<n-1
        alfa = -(r(k+1)+r(1:k)'*y(k:-1:1))/beta;
        z(1:k) = y(1:k) + alfa*y(k:-1:1);
        y(1:k+1) = [z(1:k);alfa];
    end
end

%% Trench
function B = Trench(r)
% function B = Trench(r)
% Inverse of a symmetric positive definite Toeplitz matrix.
% r is nx1 such that T = toeplitz([1;r(1:n-1)]) is positive definite
% B is the inverse of T.
% GVL4: Algorithm 4.7.3
n = length(r);
y = Durbin(r(1:n-1));
B = zeros(n,n);
gamma = 1/(1+r(1:n-1)'*y(1:n-1));
v(1:n-1) = gamma*y(n-1:-1:1);
B(1,1) = gamma;
B(1,2:n) = v(n-1:-1:1)';
for i=2:floor((n-1)/2)+1
    for j=i:n-i+1
        B(i,j) = B(i-1,j-1)+(v(n+1-j)*v(n+1-i) - v(i-1)*v(j-1))/gamma;
    end
end
% Fill in the rest of B using the fact that it is both symmetric
% and persymmetric...
for i=1:n
    for j=i+1:n
        B(j,i) = B(i,j);
    end
end
for i=1:n
    for j=1:n-i+1
        B(n-i+1,n-j+1) = B(i,j);
    end
end