% Generate a symmetric positive definite matrix A and a vector b
n = 1000;
A = rand(n);
A = 0.5 * (A + A'); % Symmetrize the matrix
A = A + n * eye(n); % Make it positive definite
b =n*rand(n, 1);
eig(A)

% Set parameters
max_iter = 100;
omega = 1.2; % Relaxation factor for SOR

% Compute the exact solution using MATLAB's backslash operator
x_exact = A \ b;
x_inital=zeros(n, 1);
% Run the iterations and collect errors
[x_jacobi, errors_jacobi] = jacobi(A, b, x_exact, max_iter, x_inital);
[x_gs, errors_gs] = gauss_seidel(A, b, x_exact,  max_iter, x_inital);
[x_sor, errors_sor] = sor(A, b, x_exact,  max_iter, omega, x_inital);

% Plot the errors
figure;
semilogy(1:max_iter, errors_jacobi, 'r-', 'LineWidth', 2); hold on;
semilogy(1:max_iter, errors_sor, 'b--', 'LineWidth', 2);
semilogy(1:max_iter, errors_gs, 'g-.', 'LineWidth', 2);
xlabel('Iteration');
ylabel('$$\|x_k - x_{exact}\|_2$$', 'Interpreter', 'latex');
legend('Jacobi', 'Gauss-Seidel', 'SOR');
title('Convergence of Iterative Methods');
grid on;

% Jacobi Iteration
function [x, errors] = jacobi(A, b, x_exact, max_iter, x_inital)
    n = length(b);
    x = x_inital; % Initial guess
    errors = zeros(max_iter, 1);
    for k = 0:max_iter-1
        x_new = zeros(n, 1);
        for i = 1:n
            sum1 = sum(A(i, 1:i-1) .* x(1:i-1)');
            sum2 = sum(A(i, i+1:n) .* x(i+1:n)');
            x_new(i) = (b(i) - sum1 - sum2) / A(i, i);
        end
        errors(k+1) = norm(x_new - x_exact);
        x = x_new;
    end
end


% Gauss-Seidel Iteration
function [x, errors] = gauss_seidel(A, b, x_exact,  max_iter,x_inital)
    n = length(b);
    x = x_inital; % Initial guess
    errors = zeros(max_iter, 1);
    for k = 1:max_iter
        x_new = x;
        for i = 1:n
            sum1 = A(i, 1:i-1) * x_new(1:i-1);
            sum2 = A(i, i+1:n) * x(i+1:n);
            x_new(i) = (b(i) - sum1 - sum2) / A(i, i);
        end
        errors(k) = norm(x_new - x_exact);
        x = x_new;
    end
end

% SOR Iteration
function [x, errors] = sor(A, b, x_exact, max_iter, omega,x_inital)
    n = length(b);
     x = x_inital; % Initial guess
    errors = zeros(max_iter, 1);
    for k = 1:max_iter
        x_new = x;
        for i = 1:n
            sum1 = A(i, 1:i-1) * x_new(1:i-1);
            sum2 = A(i, i+1:n) * x(i+1:n);
            x_new(i) = (1 - omega) * x(i) + (omega / A(i, i)) * (b(i) - sum1 - sum2);
        end
        errors(k) = norm(x_new - x_exact);
        x = x_new;
    end
end
