clear;
clc;
% LU �ֽ�
% A = L * U

A = [2, 4, -2;
     4, 9, -3;
    -2, -3, 4];

n=size(A,1);
L=eye(n);tau=zeros(n,1);U=A;

for k=1:1:n-1
    rows=k+1:n;
    tau(rows)=U(rows,k)/U(k,k);
    % ����U
    U(rows,rows)=U(rows,rows)-tau(rows)*U(k,rows);
    U(rows,k)=0;
    % ����L
    L(rows,k)=tau(rows);
end


A
L
U

%check
% L = [1, 0, 0;
%      2, 1, 0;
%      -1, 1, 1];
% U = [2, 4, -2;
%      0, 1, 1;
%      0, 0, 1];

L * U





