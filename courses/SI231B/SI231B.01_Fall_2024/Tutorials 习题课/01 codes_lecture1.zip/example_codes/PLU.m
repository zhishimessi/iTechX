clear;
clc;
%
% ����Ԫ LU �ֽ�
% A(p,:) = L * U
%

AA = [2, 4, -2;
     4, 9, -3;
    -2, -3, 4];
A = [2, 4, -2;
     4, 9, -3;
    -2, -3, 4];
n = size(A, 1);
L = eye(n);
P = eye(n);
U = A;
tau=zeros(n,1);



for k = 1 : n-1
    %�û�����
    [~, piv] = max(abs(A(k:n, k))); piv = piv-1+k;
    A([k piv],:)=A([piv k],:);
    P([k piv],:)=P([piv k],:);

    % ��¼L
    A(k+1:n, k) = A(k+1:n, k) / A(k,k);
    % ��¼U
    A(k+1:n, k+1:n) = A(k+1:n, k+1:n) - A(k+1:n, k)*A(k, k+1:n);
end

for k=1:n
    L(k+1:n, k) = A(k+1:n, k);
    U(k,k:n)=A(k,k:n);
    U(k,1:k-1)=0;
end
P
A
L
U



%check P*A=L*U
A = [2, 4, -2;
     4, 9, -3;
    -2, -3, 4];
[L, U, P] = lu(A)