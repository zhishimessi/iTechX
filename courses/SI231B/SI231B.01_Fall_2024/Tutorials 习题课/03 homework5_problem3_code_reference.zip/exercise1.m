clear;
clc;
% construct A with given eigenvalues and eigenvectors

Lam = [7, 5, 2, 4, 1];
n = length(Lam);

rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;

A
X(:,1)

niters = 10;

% TODO: initialization
for k = 1 : niters
    % TODO: write the power iteration code
end

