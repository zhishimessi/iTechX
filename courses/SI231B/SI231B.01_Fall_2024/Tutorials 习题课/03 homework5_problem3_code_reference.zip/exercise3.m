clear;
clc;

Lam = [7, 5, 2, 4, 1];
n = length(Lam);

rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;
I = eye(n);

niters = 6;

% TODO: initialization

for k = 1 : niters
    % TODO: Rayleigh quotient iteration    
    % TODO: record the error in each iteration
end

% plot
it = 1 : niters;
semilogy(it, err, 'ob');
