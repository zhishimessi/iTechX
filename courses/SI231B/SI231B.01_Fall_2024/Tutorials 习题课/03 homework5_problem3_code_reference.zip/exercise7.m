% Example usage
A = [1, 2; 3, 4];
B = [1; 0];
Q = [1, 0; 0, 1];
R = 1;

% Solve the algebraic Riccati equation
X = hamilton(A, B, Q, R);

% Display the solution
disp('Solution X:');
disp(X);

% Verify the solution by checking the Riccati equation
residual = A'*X + X*A - X*B*(R\B')*X + Q;
disp('Residual (should be close to zero):');
disp(residual);
