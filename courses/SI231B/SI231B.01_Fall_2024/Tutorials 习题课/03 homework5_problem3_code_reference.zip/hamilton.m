function X = hamilton(A, B, Q, R)
    % TODO: Construct the Hamiltonian matrix
    

    % TODO: Compute the Hamiltonian-Schur decomposition
    

    % TODO: Ensure eigenvalues are ordered so that the stable ones (with negative real parts) come first
    

    % Partition the matrix into the stable and unstable parts
    n = size(A, 1);
    U11 = U(1:n, 1:n);
    U21 = U(n+1:end, 1:n);

    % TODO: Compute the solution X
    

    % Ensure X is symmetric (ensures numerical stability)
    X = (X + X') / 2;
end
