function [Q, D] = orthogonal_iteration(A, r)
    [n, ~] = size(A);
    Q = randn(n, r);
    Q = orth(Q); % Orthonormalize the initial matrix Q
    
    niters = 1000;
    
    for i = 1:niters
        Z = A * Q;
        [Q, ~] = qr(Z, "econ"); % QR decompostion
        D = diag(diag(Q' * A * Q));
    end
end
