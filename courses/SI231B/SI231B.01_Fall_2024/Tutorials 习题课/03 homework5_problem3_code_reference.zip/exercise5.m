clear;
clc;
Lam = [27, 15, 13, 9, 9, 8]; % lambda_r > lambda_{r+1}
n = length(Lam);
rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;

A
Lam

r = 5; % Number of eigenvalues/eigenvectors to compute

[Q, D] = orthogonal_iteration(A, r);

disp('Eigenvectors (Q):');
disp(Q);
disp('Eigenvalues (D):');
disp(D);
