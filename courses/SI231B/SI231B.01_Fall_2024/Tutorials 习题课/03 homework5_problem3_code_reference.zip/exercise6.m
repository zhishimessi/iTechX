function H = hessenberg_reduction(A)
    % A: Input square matrix
    % H: Hessenberg matrix

    [n, m] = size(A);
    if n ~= m
        error('Matrix A must be square');
    end

    H = A;
    for k = 1:n-2
        % TODO: the Hessenberg reduction procedure
    end
end

% Example usage
A = [4, 1, 6, 3;
     2, 5, 8, 7;
     1, 1, 6, 2;
     9, 3, 2, 1];

H = hessenberg_reduction(A);
disp('Hessenberg matrix H:');
disp(H);
