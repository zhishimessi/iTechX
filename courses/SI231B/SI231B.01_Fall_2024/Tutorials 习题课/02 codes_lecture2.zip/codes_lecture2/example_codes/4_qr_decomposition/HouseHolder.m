% Householder method for computing the QR factorization A = QR.
% A is mxn with m>=n.
% Q_fact is mxn and  houses the factored form representation of the 
%    orthogonal factor Q.
% R is nxn and upper triangular with nonnegative diagonal entries 
%    so A = QR.

% conduct Algorithm 5.2.1 in the textbook
close;
clc;

A=[1,19,-34;-2,-5,20;2,8,37]
%A=[1,0,-1;1,2,1;1,1,-3;0,1,1] 

[m,n] = size(A);


%% Householder
[V, R] = my_househ_qr(A)
Q = eye(m);
for k = n : -1 : 1
    vk = V(:, k);
    Q = Q - 2 * vk * (vk' * Q);
end

%check
R
Q
Q*R
qrerr_house = norm(Q*R - A, 'inf')
ortherr_house = norm(Q' * Q - eye(m), 'inf')

%% 

function [V, R] = my_househ_qr(A)
[m, n] = size(A);
V = zeros(m, n);
R = A;
for k = 1 : n
    [V(k:m, k), nx] = househ_refl(R(k:m, k)); %record vk (k column of A^(k-1)) to constitute Hk
    t = V(k:m, k)' * R(k:m, k:n); 
    R(k:m, k:n) = R(k:m, k:n) - 2 * V(k:m, k) * t; %record A^(k)=H_{k-1}H_{k-2}...H_1*A % R=A^{n-1}
end

end

%% 
function [v, nx] = househ_refl(x)
v = x;
nx = norm(x, 2);

if v(1) >= 0  %determine v=v+(-)\|x\|e1 by max\|v\|
    v(1) = v(1) + nx;
    nx = -nx; % record \alpha=-\|x\|
else
    v(1) = v(1) - nx;

end

v = v / norm(v, 2); % generate v = v / \|v\|

end