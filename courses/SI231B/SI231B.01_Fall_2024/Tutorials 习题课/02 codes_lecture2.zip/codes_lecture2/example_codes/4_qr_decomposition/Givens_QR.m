% Givens method for computing the QR factorization A = QR.
% A is mxn with m>=n.
% Q is mxm and orthogonal.
% R is mxn upper triangular so A = QR.

%% Givens rotation
A=[1,19,-34;-2,-5,20;2,8,37]
%A=[1,0,-1;1,2,1;1,1,-3;0,1,1]
[R, C, S] = my_givens_qr(A);
Q = eye(m);
for j = n : -1 : 1
    for i = m : -1 : j+1
        c = C(i, j); s = S(i, j);
        Q([j, i], :) = [c, s; -s, c]' * Q([j, i], :); %Q^T=JnmJn,n+1...J1m..J12，orthogona Q
    end
end
%check
Q
R
qrerr_givens = norm(Q*R - A, 'inf')
ortherr_givens = norm(Q' * Q - eye(m), 'inf')

%% 

function [R, C, S] = my_givens_qr(A)
[m, n] = size(A);
R = A;
C = zeros(m, n);
S = zeros(m, n);
for j = 1 : n %from first column start
    for i = j+1 : m % A(i,j)--->0 by rotations
        [c, s] = givens_rot(R(j, j), R(i, j));
        C(i, j) = c; S(i, j) = s;
        R([j, i], j:n) = [c, s; -s, c] * R([j, i], j:n); %A(i,j)--->0
    end
end

end


%%  Givens rotation computation
% Determines cosine-sine pair (c,s) so that [c s;-s c]'*[a;b] = [r;0]

function [c, s] = givens_rot(a, b)

if b == 0
    c = 1; s = 0;
else
    t = sqrt(a*a + b*b);
    c = a / t;
    s = b / t;
end

end

