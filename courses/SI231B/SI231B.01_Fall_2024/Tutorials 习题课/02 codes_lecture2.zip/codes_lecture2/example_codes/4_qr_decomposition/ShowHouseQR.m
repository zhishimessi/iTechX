function ShowHouseQR(A)
% function ShowHouseQR(A)
% Illustrates Householder QR factorization.
% matrix. A call of the form ShowHouseQR() uses a random 6x4 example.
% if nargin==0
%     A = randn(6,4);
% end
A=[1,0,-1;1,2,1;1,1,-3;0,1,1]

[m,n] = size(A);
clc
fprintf('Householder QR\n\n')
disp('A = ')
fprintfM('%7.3f',A)
[Q_fact,R] = HouseQR(A);

% % Thin version...
fprintf('\nThin Version...\n\n')
Q = BackAccum(Q_fact,'thin');
disp('Q = ')
fprintfM('%7.3f',Q)
disp('R = ')
fprintfM('%7.3f',R)
fprintf('|| A - QR ||  = %10.3e\n',norm(A-Q*R))
fprintf('|| Q''Q - I || = %10.3e\n\n',norm(Q'*Q-eye(n,n)))

% % Full version...
% fprintf('\n\nFull Version...\n\n')
% Q = BackAccum(Q_fact);
% R = [R;zeros(m-n,n)];
% disp('Q = ')
% fprintfM('%7.3f',Q)
% disp('R = ')
% fprintfM('%7.3f',R)
% fprintf('|| A - QR ||  = %10.3e\n',norm(A-Q*R))
% fprintf('|| Q''Q - I || = %10.3e\n\n',norm(Q'*Q-eye(m,m)))

function [Q_fact,R] = HouseQR(A)
% function [Q_fact,R] = HouseQR(A)
% Householder method for computing the QR factorization A = QR.
% A is mxn with m>=n.
% Q_fact is mxn and  houses the factored form representation of the 
%    orthogonal factor Q.
% R is nxn and upper triangular with nonnegative diagonal entries 
%    so A = QR.
% GVL4: Algorithm 5.2.1
[m,n] = size(A);
for j=1:min(n,m-1)
    % Compute the jth Householder matrix Q{j}...
    [v,beta] = House(A(j:m,j));
    % Update...
    % A = Q{j}A
    A(j:m,j:n) = A(j:m,j:n) - (beta*v)*(v'*A(j:m,j:n));
    % Save the Householder vector...
    A(j+1:m,j) = v(2:m-j+1);
end
R = triu(A(1:n,1:n))
Q_fact = tril(A,-1)



 function [v,beta] = House(x)
% function [v,beta] = house(x)
% Householder vector computation
% x is a column m-vector.
% v is a column m-vector with v(1) = 1 and beta is a scalar such
% that P = I - beta*v*v' is orthogonal and Px = norm(x)*e1.
% GVL4: Algorithm 5.1.1
m = length(x);
if m>1
sigma = x(2:m)'*x(2:m); v = [1;x(2:m)];
if sigma==0 && x(1)>0
    beta = 0;
elseif sigma==0 && x(1)<0
    beta = 2;
else
    mu = sqrt(sigma + x(1)^2);
    if x(1)<0
        v(1) = x(1) - mu;
    else
        v(1) = -sigma/(x(1)+mu);
    end
    beta = 2*v(1)^2/(sigma+v(1)^2);
    v = v/v(1);
end
else
    v = 0; beta = 0;
end

function Q = BackAccum(Q_fact,type)
% function Q = BackAccum(Q_fact,type)
% Explicit formation of an orthogonal matrix from its factored form
%   representation. Uses backward accumulation.
% Q_fact is mxn and Q_fact(j+1:m,j) is the essential part of the 
% jth Householder matrix Q_{j}.
% A call of the form BackAccum(Q_fact,'thin') produces a "thin", mxn Q
% with orthonormal columns, the first n columns of Q_{1}...Q_{n}.
% A call of the form BackAccum(Q_fact) produces an mxm Q
% that is the product of of Q_{1}...Q_{n}.
% GVL4: Section 5.2.2
[m,n] = size(Q_fact);
if nargin==2 && m>n && strcmp(type,'thin')
   Q = [];
   for j=n:-1:1
      v = [1;Q_fact(j+1:m,j)];
      beta = 2/(v'*v);
      k = m-j;
      Q = [1 zeros(1,n-j);zeros(m-j,1) Q];
      if norm(Q_fact(j+1:m,j))>0
         Q = Q - (beta*v)*(v'*Q);
      end
   end
else
   Q = eye(max(m-n,1),max(m-n,1));
   for j=min(n,m-1):-1:1
      v = [1;Q_fact(j+1:m,j)];
      beta = 2/(v'*v);
      k = m-j;
      Q = [1 zeros(1,k);zeros(k,1) Q];
      if norm(Q_fact(j+1:m,j))>0
         Q = Q - (beta*v)*(v'*Q);
      end
   end
end

