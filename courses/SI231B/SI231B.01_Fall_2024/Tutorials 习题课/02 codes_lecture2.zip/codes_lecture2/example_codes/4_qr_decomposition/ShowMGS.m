 function ShowMGS(A)
% function ShowMGS(A)
% Illustrates Modified Gram-Schmidt on an mxn A with m>=n.
% A call of the form ShowMGS() uses a random ill-conditioned 6x4 example.
% if nargin==0
%     A = gallery('randsvd', [6,4],10^6,3);
% end
A=[1,1,1;0.001,0.001,0;0.001,0,0.001]

[m,n] = size(A);
[Q,R] = MGS(A);
clc
fprintf('Modified Gram-Schmidt\n\n')
disp('A = ')
fprintfM('%7.3f',A)
disp('Q = ')
fprintfM('%7.3f',Q)
disp('R = ')
fprintfM('%7.3f',R)
fprintf('|| A - QR ||  = %10.3e\n\n',norm(A-Q*R))
fprintf('|| Q''Q - I || = %10.3e\n\n',norm(Q'*Q-eye(n,n)))
fprintf('Condition of A  = %10.3e\n\n',cond(A,2))

function [Q,R] = MGS(A)
% function [Q,R] = MGS(A)
% Modified Gram-Schmidt computation of the thin QR factorization A = QR
% A is mxn.   Assume m>=n and full rank.
% Q is mxn with orthonormal columns.
% R is nxn upper triangular with positive diagonal entries.
% GVL4: Section 5.2.8
[m,n] = size(A);
R = zeros(n,n);
Q = zeros(m,n);
for k=1:n
    R(k,k) = norm(A(:,k));
    Q(:,k) = A(:,k)/R(k,k);
    R(k,k+1:n) = Q(:,k)'*A(:,k+1:n);
    A(:,k+1:n) = A(:,k+1:n) - Q(:,k)*R(k,k+1:n);
end