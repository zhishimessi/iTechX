function ShowGivensQR(A)
% function ShowGivensQR(A)
% Illustrates Givens QR factorization of an mxn A with m>=n.
% A call of the form ShowGivensQR() uses a random 6x4 example.
% if nargin==0
%     A = randn(6,4);
% end
A=[1,19,-34;-2,-5,20;2,8,37]
n = length(A);
[Q,R] = GivensQR(A);
clc
fprintf('Givens QR\n\n')
disp('A = ')
fprintfM('%7.3f',A)
disp('Q = ')
fprintfM('%7.3f',Q)
disp('R = ')
fprintfM('%7.3f',R)
fprintf('|| A - QR ||  = %10.3e\n\n',norm(A-Q*R))
fprintf('|| Q''Q - I || = %10.3e\n\n',norm(Q'*Q-eye(n,n)))

function [Q,R] = GivensQR(A)
% function [Q,R] = GivensQR(A)
% Givens method for computing the QR factorization A = QR.
% A is mxn with m>=n.
% Q is mxm and orthogonal.
% R is mxn upper triangular so A = QR.
% GVL4: Algorithm 5.2.4
[m,n] = size(A);
Q = eye(m,m);
for j=1:n
    for i=m:-1:j+1
        [c,s] = Givens(A(i-1,j),A(i,j));
        A(i-1:i,j:n) = [c s;-s c]'*A(i-1:i,j:n);
        Q(:,i-1:i) = Q(:,i-1:i)*[c s ;-s c];
    end
end
R = A;

 function [c,s] = Givens(a,b)
% function [c,s] = Givens(a,b)
% Givens rotation computation
% Determines cosine-sine pair (c,s) so that [c s;-s c]'*[a;b] = [r;0]
% GVL4: Algorithm 5.1.3
if b==0
    c = 1; s = 0;
else
    if abs(b)>abs(a)
        tau = -a/b; s = 1/sqrt(1+tau^2); c = s*tau;
    else
        tau = -b/a; c = 1/sqrt(1+tau^2); s = c*tau;
    end
end
