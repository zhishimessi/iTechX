% Classical Gram-Schmidt computation of the thin QR factorization A = QR.
% A is mxn. Assume m>=n and full rank.
% Q is mxn with orthonormal columns.
% R is nxn upper triangular with positive diagonal entries.
%5.2.7 classical Gram-Schmidt (CGS) in the textbook 
%% 
close;
clc
A=[0,-20,-14;3,27,-4;4,11,-2]
%A=[1,0,-1;1,2,1;1,1,-3;0,1,1]
rankA=rank(A)
[m,n] = size(A);
R1 = zeros(n,n);
Q1 = zeros(m,n);

R1(1,1) = norm(A(:,1)); 
Q1(:,1) = A(:,1)/R1(1,1);
for i=2:n
    R1(1:i-1,i) = Q1(:,1:i-1)'*A(:,i); %compute rjk, j=1,...i-1
    z = A(:,i) - Q1(:,1:i-1)*R1(1:i-1,i); %compute \tilde{qi}
    R1(i,i) = norm(z); %compute rii
    Q1(:,i) = z/R1(i,i); %computer qi
end




Q1
R1

%check
QRdecomposition=Q1*R1
norm(A-Q1*R1) %check A=QR
norm(Q1'*Q1-eye(n,n)) %check semi-orthongonal of Q 


 

