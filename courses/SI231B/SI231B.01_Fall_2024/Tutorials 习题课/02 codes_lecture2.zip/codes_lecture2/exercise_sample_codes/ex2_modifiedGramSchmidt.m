% Modified Gram-Schmidt computation of the thin QR factorization A = QR
% A is mxn.   Assume m>=n and full rank.
% Q is mxn with orthonormal columns.
% R is nxn upper triangular with positive diagonal entries.
close;
clc;
A=[1,1,1;0.001,0,0;0,0.001,0;0,0,0.001]
rank(A)
[m,n] = size(A);
%write the thin QR factorization code by using Modified Gram-Schmidt 

% hint:% conduct Algorithm 5.2.6 in the textbook




Q
R

QRdecomposition=Q*R %check A=QR
%check

norm(Q'*Q-eye(n,n)) %check semi-orthongonal of Q 
