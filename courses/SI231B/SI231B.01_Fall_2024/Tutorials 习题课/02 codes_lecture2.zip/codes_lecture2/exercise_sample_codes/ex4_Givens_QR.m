% Givens method for computing the QR factorization A = QR.
% A is mxn with m>=n.
% Q is mxm and orthogonal.
% R is mxn upper triangular so A = QR.

%% Givens rotation
A=[1,0,-1;1,2,1;1,1,-3;0,1,1]

%write the QR factorization  code by using given rotation method
% hint： refer to Algorithm 5.2.4 in the textbook "Matrix computations 4rd by Gene H. Golub"


Q
R
qrerr_givens = norm(Q*R - A, 'inf')
ortherr_givens = norm(Q' * Q - eye(m), 'inf')


