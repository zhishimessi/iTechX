%% Linear prediction by least squares
% The example illustrates the prediction of data using a linear predictor.
% The coefficients of the linear predictor are obtained by least squares.
%
%  Ivan Selesnick
% selesi@poly.edu

%% Start

clear
clc
close all

%% Load data

load data.txt;
whos

y = data;         % data value

%% Display data

figure(1)
plot(y)
title('Data')

%% Linear predictor coefficients (2)
L = 100; 
N = length(y)
H = [y(2:N-1) y(1:N-2)]       % H : rectangular matrix
b = y(3:N);     size(b)                % b : right-hand side of linear system of equations
a = (H' * H) \ (H' * b)         % a : coefficients of linear predictor

%%
                      % L : number of values to predict
g = [y; zeros(L, 1)];           % g : extended array (use first N samples to predict later samples)
for i = N+1:N+L   
    g(i) = a(1) * g(i-1) + a(2) * g(i-2);    % linear prediction
end

figure(2)
plot(g)
line([N N], [-2 2], 'linestyle', '--')
title('Data and predicted values')


%% Linear predictor coefficients (3)
%plot the linear prediction result with a1,a2,a3 


%% Linear predictor coefficients (4)

%plot the linear prediction result with a1,a2,a3 ,a4


%% Linear predictor coefficients (6)

%plot the linear prediction result with a1,a2,a3 ,a4,a5,a6



