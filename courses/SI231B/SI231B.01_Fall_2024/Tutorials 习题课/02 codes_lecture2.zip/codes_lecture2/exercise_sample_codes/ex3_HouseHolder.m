% Householder method for computing the QR factorization A = QR.
% A is mxn with m>=n.
% Q_fact is mxn and  houses the factored form representation of the 
%    orthogonal factor Q.
% R is nxn and upper triangular with nonnegative diagonal entries 
%    so A = QR.
close;
clc;


A=[1,0,-1;1,2,1;1,1,-3;0,1,1]

[m,n] = size(A);
In = eye(n);
Im = eye(m);



%% Householder
% write the QR factorization A = QR code by using  Householder method 
% hint： refer to Algorithm 5.2.1 in the textbook "Matrix computations 4rd by Gene H. Golub"
%check
R
Q
Q*R
qrerr_house = norm(Q*R - A, 'inf')
ortherr_house = norm(Q' * Q - Im, 'inf')

