%% Least square deconvolution
% This example illustrates devonvolution using least squares
%
%  Ivan Selesnick
% selesi@poly.edu


%% Start

clear
close all


%% Create data

N = 300;
n = (0:N-1)';                               % n : discrete-time index

w = 5;
n1 = 70;
n2 = 130;
x = 2.1 * exp(-0.5*((n-n1)/w).^2) - 0.5*exp(-0.5*((n-n2)/w).^2).*(n2 - n);    % x : input signal

h = n .* (0.9 .^n) .* sin(0.2*pi*n);        % h : impulse response


figure(1)
clf
subplot(2, 1, 1)
plot(x)
title('Input signal');
YL1 = [-2 3];
ylim(YL1);

subplot(2, 1, 2)
plot(h)
title('Impulse response');


%% Output data

randn('state', 0);                          % Set state for reproducibility

y = conv(h, x);
y = y(1:N);                                 % y : output signal (noise-free)

yn = y + 0.2 * randn(N, 1);                 % yn : output signal (noisy)

figure(2)
clf
subplot(2, 1, 1)
plot(y);
YL2 = [-7 13];
ylim(YL2);
title('Output signal');

subplot(2, 1, 2)
plot(yn);
title('Output signal (noisy)');
ylim(YL2);


%% Convolution matrix H
% Create convolution matrix H and 
% verify that H*x is the same as y

H = convmtx(h, N);
H = H(1:N, :);                              % H : convolution matrix

% Verify that H*x is the same as y
e = y - H * x;   % should be zero
max(abs(e))

%% Direct solve (fails)
% Attempting to solve H*x = y leads to a solution
% of all NaN's (not a number)

g = H \ y

%  H is singular

%%

g(1:10)


%% Diagonal loading (noise-free)
% Diagonal overcomes the singularity of H.

% plot signal x under noise-free, lam=0.1
% plot signal x under noise-free, lam=1


%% Diagonal loading (noisy)

% plot signal x under noisy, lam=0.1

% plot signal x under noisy, lam=1







%%


