% Classical Gram-Schmidt computation of the thin QR factorization A = QR.
% A is mxn. Assume m>=n and full rank.
% Q is mxn with orthonormal columns.
% R is nxn upper triangular with positive diagonal entries.
%% exercise 1
A=[1,0,-1;1,2,1;1,1,-3;0,1,1]
rankA=rank(A)
[m,n] = size(A);
R = zeros(n,n);
Q = zeros(m,n);
%wirte the thin QR factorization code by using   Gram-Schmidt 
% hint: conduct 5.2.7 classical Gram-Schmidt (CGS) in the textbook 
Q
R

%check
Q*R
norm(A-Q*R) %check A=QR
norm(Q'*Q-eye(n,n)) %check semi-orthongonal of Q 


 

