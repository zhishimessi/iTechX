#include<iostream>
#include<algorithm>
using namespace std;
const int N=2e5;
long long a[N+1];
long long b[N+1];
int main()
{
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		a[i]*=min(n-k+1,i)-max(1,i-k+1)+1;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	long long res=0;
	for(int i=1;i<=n;i++)
	{
		res+=a[i]*b[n-i+1];
	}
	cout<<res<<endl;
	return 0;
}
