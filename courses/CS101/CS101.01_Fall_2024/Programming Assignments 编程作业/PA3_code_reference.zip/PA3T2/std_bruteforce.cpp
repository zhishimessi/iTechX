#include<iostream>
#include<algorithm>
using namespace std;
const int N=2e5;
long long a[N+1];
long long b[N+1];
long long p[N+1];
long long calc(int n,int k)
{
	long long res=0;
	for(int i=1;i<=n-k+1;i++)
	{
		for(int j=i;j<i+k;j++)
		{
			res+=a[j]*b[p[j]];
		}
	}
	return res;
}
int main()
{
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i];
		p[i]=i;
	}
	long long minn=-1;
	do
	{
		long long res=calc(n,k);
		if(minn==-1||minn>res)
		{
			minn=res;
		}
	}while(next_permutation(p+1,p+n+1));
	cout<<minn<<endl;
	return 0;
}
