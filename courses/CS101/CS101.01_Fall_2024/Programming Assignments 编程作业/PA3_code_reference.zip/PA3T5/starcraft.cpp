#include <algorithm>
#include <cstdio>
#include <iostream>
#include <vector>

using std::vector;

int n, W, k;  // n: number of equipment, W: capacity, k: mission number
struct eqp {
    int l, w, v;  // l: number, w: weight, v: value
    eqp(int _l, int _w, int _v)
        : l(_l), w(_w), v(_v) {}
};
vector<eqp> equipment;

/*
You can share a public variable(function) sets since only 1 mission will be executed once.
*/

// MISSION1: all equipment with l = -1
int Mission1() {
    vector<int> dp(W + 1, 0);
    for (auto [l, w, v] : equipment)
        for (int j = w; j <= W; ++j)
            dp[j] = std::max(dp[j], dp[j - w] + v);
    return dp[W];
}

// MISSION2: all equipment with l = 1
int Mission2() {
    vector<int> dp(W + 1, 0);
    for (auto [l, w, v] : equipment)
        for (int j = W; j >= w; --j)
            dp[j] = std::max(dp[j], dp[j - w] + v);
    return dp[W];
}

// MISSION3: Liquid tanks: Can bring any fractional unit of liquid, w|v
int Mission3() {
    int ans = 0;
    std::sort(equipment.begin(), equipment.end(), [](const eqp& a, const eqp& b) { return a.v * b.w > b.v * a.w; });
    for (auto [l, w, v] : equipment) {
        if (l == -1)
            l = W;
        if (W >= w * l) {
            W -= w * l;
            ans += v * l;
        } else {
            ans += v * W / w;
            break;
        }
    }
    return ans;
}

// Input Part, you can modify this.
void getInput() {
    scanf("%d%d%d", &k, &n, &W);
    for (int i = 1; i <= n; ++i) {
        int l, w, v;
        scanf("%d%d%d", &l, &w, &v);
        equipment.emplace_back(l, w, v);
    }
}

// You'd better not to modify things below.
int (*MISSION_FUNC[])() = {nullptr, Mission1, Mission2, Mission3};

int main() {
#ifndef ONLINE_JUDGE
    freopen("starcraft.in", "r", stdin);
    freopen("starcraft.out", "w", stdout);
#endif
    getInput();
    int ans = MISSION_FUNC[k]();
    std::cout << ans;
    return 0;
}