#include <iostream>
#include <queue>
#include <vector>
const int N = 1e2 + 9, MAXT = 1e5;

int n, m, t0, S, T, a[N];
bool dp[N][MAXT];

struct Edge {
    int v, w, f, d;
};
std::vector<Edge> adjList[N];

int main() {
#ifndef ONLINE_JUDGE
    freopen("bus.in", "r", stdin);
    freopen("bruteforce.out", "w", stdout);
#endif
    std::ios::sync_with_stdio(false);
    std::cin >> n >> m >> t0 >> S >> T;
    for (int i = 1; i <= m; ++i) {
        int l, w, f, d;
        std::cin >> l >> f >> d;
        for (int j = 1; j <= l; ++j)
            std::cin >> a[j];
        for (int j = 1; j <= l - 1; ++j) {
            std::cin >> w;
            adjList[a[j]].push_back({a[j + 1], w, f, d});
            f += w;
        }
    }
    dp[S][t0] = true;
    for (int t = t0; t < MAXT - 2 * N; ++t) {
        if (dp[T][t]) {
            std::cout << t << std::endl;
            return 0;
        }
        for (int u = 1; u <= n; ++u) {
            if (dp[u][t] == false)
                continue;
            // if (t == 0 or dp[u][t - 1] == false)
            //     std::cout << u << " first " << t << std::endl;

            dp[u][t + 1] = true;  // wait at stop u
            for (auto [v, w, f, d] : adjList[u]) {
                if (t >= f and (t - f) % d == 0)
                    dp[v][t + w] = true;  // board the bus
            }
        }
    }
    std::cout << "-1" << std::endl;
    return 0;
}