#include <climits>
#include <iostream>
#include <queue>
#include <vector>
const int N = 1e6 + 9;

int n, m, S, T, a[N];
long long t0, dis[N];
bool vis[N];

struct Edge {
    int v;
    long long w, f, d;
};
std::vector<Edge> adjList[N];

struct Pair {
    int v;
    long long w;
    inline bool operator<(const Pair& other) const { return w > other.w; }
};
std::priority_queue<Pair> fringe;

int main() {
#ifndef ONLINE_JUDGE
    freopen("bus.in", "r", stdin);
    freopen("bus.out", "w", stdout);
#endif
    std::ios::sync_with_stdio(false);
    std::cin >> n >> m >> t0 >> S >> T;
    for (int i = 1; i <= m; ++i) {
        int l;
        long long w, f, d;
        std::cin >> l >> f >> d;
        for (int j = 1; j <= l; ++j)
            std::cin >> a[j];
        for (int j = 1; j <= l - 1; ++j) {
            std::cin >> w;
            adjList[a[j]].push_back({a[j + 1], w, f, d});
            f += w;
        }
    }
    for (int i = 1; i <= n; ++i)
        dis[i] = LLONG_MAX;
    dis[S] = t0;
    fringe.push({S, dis[S]});
    while (!fringe.empty()) {
        int u = fringe.top().v;
        fringe.pop();
        if (vis[u])
            continue;
        // std::cout << u << " first " << dis[u] << std::endl;
        vis[u] = true;
        if (u == T) {
            std::cout << dis[u] << std::endl;
            return 0;
        }
        for (auto [v, w, f, d] : adjList[u]) {
            long long wait = std::max(dis[u], f);
            wait += (d - (wait - f) % d) % d;
            if (dis[v] > wait + w) {
                dis[v] = wait + w;
                fringe.push({v, dis[v]});
            }
        }
    }
    std::cout << -1 << std::endl;
    return 0;
}