#include <iostream>
const int N = 1e5 + 9, MOD = 1e9 + 7;
int s, t, k, m, a[20];

struct NumMod {
    int v;
    bool greater_than_MOD;
    NumMod operator+(const NumMod& other) {
        if (v + other.v >= MOD)
            return {v + other.v - MOD, true};
        else
            return {v + other.v, greater_than_MOD or other.greater_than_MOD};
    }
    bool operator<(int a) {
        return !greater_than_MOD and v < a;
    }
} dp[N][10];

int main() {
#ifndef ONLINE_JUDGE
    freopen("continuous.in", "r", stdin);
    freopen("continuous.out", "w", stdout);
#endif
    std::ios::sync_with_stdio(false);
    std::cin >> s >> t >> k >> m;
    dp[k][t] = {1, false};
    for (int i = k - 1; i >= 1; --i) {
        dp[i][0] = dp[i + 1][1];
        dp[i][9] = dp[i + 1][8];
        for (int j = 1; j <= 8; ++j) {
            dp[i][j] = dp[i + 1][j - 1] + dp[i + 1][j + 1];
        }
    }
    std::cout << dp[1][s].v << std::endl;
    while (m--) {
        int a, j = s;
        std::cin >> a;
        if (dp[1][s] < a) {
            std::cout << -1 << std::endl;
            continue;
        }
        std::cout << (char)(j + '0');
        for (int i = 1; i < k; ++i) {
            if (j == 0)
                j = 1;
            else if (j == 9)
                j = 8;
            else if (dp[i + 1][j - 1] < a) {
                a -= dp[i + 1][j - 1].v;
                j = j + 1;
            } else
                j = j - 1;
            std::cout << (char)(j + '0');
        }
        std::cout << std::endl;
    }
    return 0;
}