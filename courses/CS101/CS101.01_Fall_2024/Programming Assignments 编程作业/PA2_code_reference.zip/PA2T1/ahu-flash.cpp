#include <algorithm>
#include <cstdio>
#include <queue>
#include <tuple>
#include <vector>

const int MAXN = 1e6 + 1, root = 1, MAXC = 1e3 + 1;

int n, ans = 1;
int lc[MAXN], rc[MAXN], color[MAXN];
int depth[MAXN], size[MAXN], lname[MAXN], rname[MAXN];
std::vector<int> layer[MAXN];
long long ltuple[MAXN], rtuple[MAXN], sort_tuple[2 * MAXN];

void dfs(int u) {
    layer[depth[u]].push_back(u);
    if (lc[u] != 0) {
        depth[lc[u]] = depth[u] + 1;
        dfs(lc[u]);
    }
    if (rc[u] != 0) {
        depth[rc[u]] = depth[u] + 1;
        dfs(rc[u]);
    }
    size[u] = size[lc[u]] + size[rc[u]] + 1;
}

int main() {
#ifndef ONLINE_JUDGE
    freopen("testcase/tree25.in", "r", stdin);
#endif
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        scanf("%d", color + i);
    }
    for (int i = 1; i <= n; i++) {
        scanf("%d%d", lc + i, rc + i);
        if (lc[i] == -1)
            lc[i] = 0;
        if (rc[i] == -1)
            rc[i] = 0;
    }
    dfs(root);
    lname[0] = rname[0] = -1;
    for (int i = n - 1; i >= 0; --i) {
        int m = 0;
        for (auto u : layer[i]) {
            if (lname[lc[u]] == rname[rc[u]])
                ans = std::max(ans, size[u]);
            ltuple[u] = (lname[lc[u]] * MAXC + color[u]) * MAXN + lname[rc[u]];
            rtuple[u] = (rname[rc[u]] * MAXC + color[u]) * MAXN + rname[lc[u]];
            sort_tuple[m++] = ltuple[u];
            sort_tuple[m++] = rtuple[u];
        }
        std::sort(sort_tuple, sort_tuple + m);
        m = std::unique(sort_tuple, sort_tuple + m) - sort_tuple;
        for (auto u : layer[i]) {
            lname[u] = std::lower_bound(sort_tuple, sort_tuple + m, ltuple[u]) - sort_tuple;
            rname[u] = std::lower_bound(sort_tuple, sort_tuple + m, rtuple[u]) - sort_tuple;
        }
    }
    printf("%d", ans);
}
