#include <climits>
#include <iostream>
#include <stack>
const int N = 1e6 + 9;
int v[N], minv[N], maxv[N], p[N];
int main() {
#ifndef ONLINE_JUDGE
    freopen("in.in", "r", stdin);
    freopen("stack.out", "w", stdout);
#endif
    int n;
    std::cin >> n;
    for (int i = 1; i <= n; ++i) {
        std::cin >> v[i];
    }
    std::stack<int> s;
    s.push(n);
    minv[n] = INT_MIN;
    maxv[n] = INT_MAX;
    for (int i = n - 1; i >= 1; --i) {
        if (v[i] > v[s.top()]) {
            if (v[i] > maxv[s.top()]) {
                std::cout << "Not exist" << std::endl;
                return 0;
            }
            minv[i] = v[s.top()];
            maxv[i] = maxv[s.top()];
        } else {
            while (v[i] < minv[s.top()])
                s.pop();
            minv[i] = minv[s.top()];
            maxv[i] = v[s.top()];
        }
        p[i] = s.top();
        s.push(i);
    }
    for (int i = 1; i <= n - 1; ++i)
        std::cout << p[i] << ' ';
    std::cout << std::endl;
}