#include <iostream>
const int N = 1e6 + 9;
int v[N], p[N];
bool IsPostOrd(int l, int r) {
    if (l >= r)
        return true;
    int k = l;
    while (k < r && v[k] < v[r])
        ++k;
    for (int i = k; i < r; ++i)
        if (v[i] < v[r])
            return false;
    if (l <= k - 1)
        p[k - 1] = r;
    if (k <= r - 1)
        p[r - 1] = r;
    return IsPostOrd(l, k - 1) and IsPostOrd(k, r - 1);
}
int main() {
#ifndef ONLINE_JUDGE
    freopen("in.in", "r", stdin);
    freopen("divide_bruteforce.out", "w", stdout);
#endif
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; ++i)
        scanf("%d", &v[i]);
    if (IsPostOrd(1, n)) {
        for (int i = 1; i <= n - 1; ++i)
            printf("%d ", p[i]);
        printf("\n");
    } else
        printf("Not exist\n");
}