open Testlib
open Util.Assert
open X86
open Ll
module Driver = Oat.Driver
module Backend = Oat.Backend
module Typechecker = Oat.Typechecker
module Frontend = Oat.Frontend
module Tctxt = Oat.Tctxt
open Backend
open Driver

(* Use this file to create additional test cases here to help you   *)
(* debug your comiplper                                             *)

let student_local_tests : suite = [
  
] 
