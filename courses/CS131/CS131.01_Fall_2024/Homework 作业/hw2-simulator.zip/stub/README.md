# HW2: x86lite simulator

Quick Start:

1. clone this repository using `git clone`
2. open the folder in VSCode (it will prompt you to "Reopen in dev container" -- do that)
3. start an OCaml sandbox terminal
4. run `make test` from the command line
5. open `bin/simulator.ml`

See the general toolchain and project instructions on the course web site. The
course web pages have a link to the html version of the homework instructions.

