function refund(int orderID):
  % cancel a ticket according to orderID you generate
  % no illegal input will occur
  % no endorse function, because it can be realized by refund then buyTicket