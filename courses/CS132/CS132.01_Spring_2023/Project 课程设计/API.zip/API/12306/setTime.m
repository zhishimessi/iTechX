function setTime(int hour, int minute): 
  % your software should have a system time, which can flow itself by timer and be easy to control and modify
  % when we set the time, system should accelerate to target time rather than jumping to target time.
  % when testing, time should be paused in default, time will only flow when we call this function.
  % when testing, illegal input will be avoided, time won't trace back.