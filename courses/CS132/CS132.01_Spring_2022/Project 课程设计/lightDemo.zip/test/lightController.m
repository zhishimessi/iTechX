classdef lightController < handle
    properties
        state=0;
        lightUI
        t
        greenTime=5;
        yellowTime=1;
        redTime=2;
        greenCount=0;
        yellowCount=0;
        redCount=0;
    end
    
    methods
        function obj=lightController()
            obj.lightUI=lightUI;
            obj.lightUI.controller=obj;
            obj.t=timer;
            obj.t.TimerFcn=@obj.countOneSec;
            obj.t.Period=1;
            obj.t.ExecutionMode='fixedRate';
        end
        
        function countOneSec(Obj,~,~)
            switch Obj.state
                case 0
                case 1
                    if Obj.greenCount>=Obj.greenTime
                        Obj.state=2;
                        Obj.greenCount=0;
                    else
                        Obj.greenCount=Obj.greenCount+1;
                    end
                case 2
                    if Obj.yellowCount>=Obj.yellowTime
                        Obj.state=3;
                        Obj.yellowCount=0;
                    else
                        Obj.yellowCount=Obj.yellowCount+1;
                    end
                case 3
                    if Obj.redCount>=Obj.redTime
                        Obj.state=1;
                        Obj.redCount=0;
                    else
                        Obj.redCount=Obj.redCount+1;
                    end
                    
            end
            Obj.lightUI.changeColor(Obj.state);
        end
        
    end
    
    
    
end