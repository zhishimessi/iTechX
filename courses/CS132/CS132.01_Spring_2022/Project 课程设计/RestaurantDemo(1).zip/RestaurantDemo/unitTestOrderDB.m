classdef unitTestOrderDB < matlab.unittest.TestCase
    methods (Test)
        function testRegister(testCase) % T1.1
            % State: No orders submitted yet
            % Input: New order od
            % Expected Output: od registered in the orderList in Database
            db=OrderDB;
            table='Table 1';
            itemList={'test' 1 20};
            od=Order;
            od.table=table;
            od.items=itemList;
            od.startTime=datestr(now,'HH:MM:SS');
            % Execute the function
            db.register(od);
            % Check expected output
            testCase.verifyEqual(od,db.orderList(1));
            
        end
        function testretrieve(testCase) % T1.2
            % State: There are incomplete orders in the orderList
            % Input: None
            % Expected Output: an order list the same as orderList in the Database 
            db=OrderDB;
            table='Table 1';
            itemList={'test' 1 20};
            od=Order;
            od.table=table;
            od.items=itemList;
            od.startTime=datestr(now,'HH:MM:SS');
            db.register(od);
            % Execute the function
            list=db.retrieve();
            % Check expected output
            testCase.verifyEqual(list,db.orderList);
        end
        function testupdatesucc(testCase)% T1.3.1
            % State: An incomplete order exists for the table
            % Input: A new order
            % Expected Output: The order in the database updated to the new
            % order and succ equal to 1
            db=OrderDB;
            table='Table 1';
            itemList={'test' 1 20};
            od=Order;
            od.table=table;
            od.items=itemList;
            od.startTime=datestr(now,'HH:MM:SS');
            db.register(od);
            od.items={'test' 2 20};
            % Execute the function
            succ=db.update('Table 1',od);
            % Check expected output
            testCase.verifyEqual(od,db.orderList(1));
            testCase.verifyEqual(succ,1);
        end
        function testupdatefail(testCase) % T1.3.2
            % State: There are orders in the database but no incomplete
            % order for that table
            % Input: A new order
            % Expected Output: succ equal to 0
            db=OrderDB;
            table='Table 1';
            itemList={'test' 1 20};
            od=Order;
            od.table=table;
            od.items=itemList;
            od.startTime=datestr(now,'HH:MM:SS');
            db.register(od);
            od.status='Complete';
            % Execute the function
            succ=db.update('Table 1',od);
            % Check expected output
            testCase.verifyEqual(succ,0);
        end
    end
    
end