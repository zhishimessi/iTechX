classdef OrderProcessor < handle
    
    properties
        serverApp
        chefApp
        orderDB
    end
    
    methods
        function od=createOrder(process,table,itemList)
            od=Order;
            od.table=table;
            od.items=itemList;
            od.startTime=datestr(now,'HH:MM:SS');
            process.orderDB.register(od);
            process.displayMessage(sprintf('Order for %s Registered',od.table));
            process.displayOrder(od);
        end
        function od=getOrder(process,tableName)
            list=process.orderDB.retrieve();
            od=[];
            for i=1:length(list)
                if strcmp(list(i).table,tableName) && ~strcmp(list(i).status,'completed')
                    od=list(i);
                    break;
                    
                end
            end
            
        end
        function displayMessage(process,Message)
                process.serverApp.Message.Text=[process.serverApp.Message.Text;{Message}];
        end
        function displayOrder(process,od)
            switch od.table
                case 'Table 1'
                    process.chefApp.OrderList1.Data=[od.items(:,1:2),repmat({false},size(od.items,1),1)];
                case 'Table 2'
                    process.chefApp.OrderList2.Data=[od.items(:,1:2),repmat({false},size(od.items,1),1)];
                case 'Table 3'
                    process.chefApp.OrderList3.Data=[od.items(:,1:2),repmat({false},size(od.items,1),1)];
            end
        end
    end
    
    
end