classdef testServerAPP < matlab.uitest.TestCase
    properties
        App
    end
    
    methods (TestMethodSetup)
        function launchApp(testCase)
            
            testCase.App = ServerUI;
            db=OrderDB;
            pro=OrderProcessor;
            pro.serverApp=testCase.App;
            pro.orderDB=db;
            testCase.App.OrderProcessor=pro;
            testCase.addTeardown(@delete,testCase.App);
        end
    end
    methods (Test)
        function test_SelectButtonPushed(testCase)
            % State: No order for the table and no dish selected
            % Input: Choose appetizer 1 and press select button
            % Expected Output: OrderList has appetizer 1's name, amount and
            % unit price
            testCase.choose(testCase.App.appetizer1Node);
            pause(0.5)
            testCase.press(testCase.App.SelectButton);
            pause(0.5)
            testCase.verifyEqual(testCase.App.OrderList.Data{1},testCase.App.appetizer1Node.Text);
             testCase.verifyEqual(testCase.App.OrderList.Data{2},1);
              testCase.verifyEqual(testCase.App.OrderList.Data{3},testCase.App.appetizer1Node.NodeData);
        end
        
    end
    
end